using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
namespace BookCourse.Editor
{
    public static class BuildWindows
    {
        [MenuItem("Book/Build Windows x64")]
        public static void Execute()
        {
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Standalone, BuildTarget.StandaloneWindows64))
                throw new InvalidOperationException("Install Windows Build Support for Unity 2018.1.0f1.");
            string[] scenes = EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path).ToArray();
            if (scenes.Length == 0) throw new InvalidOperationException("No scenes in Build Settings.");
            PlayerSettings.companyName = "Unity Book Study";
            PlayerSettings.productName = "Hour08";
            PlayerSettings.defaultScreenWidth = 1000;
            PlayerSettings.defaultScreenHeight = 700;
            string output = Path.GetFullPath("Builds/Hour08/Hour08.exe");
            Directory.CreateDirectory(Path.GetDirectoryName(output));
            var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions {
                scenes = scenes, locationPathName = output,
                target = BuildTarget.StandaloneWindows64, options = BuildOptions.None });
            if (report.summary.result != BuildResult.Succeeded)
                throw new Exception("Windows build failed: " + report.summary.result);
            Debug.Log("BOOK_BUILD_SUCCEEDED " + output);
        }
    }
}
