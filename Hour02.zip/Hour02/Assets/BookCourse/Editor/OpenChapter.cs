using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using System.IO;
namespace BookCourse.Editor
{
    [InitializeOnLoad]
    public static class OpenChapter
    {
        static OpenChapter() { EditorApplication.delayCall += Open; }
        static void Open()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating) { EditorApplication.delayCall += Open; return; }
            string key = "BookCourse.Open.OriginalAssets.2026." + Application.dataPath;
            if (EditorPrefs.GetBool(key, false)) return;
            string path = "Assets/Scenes/03_Exercise_ParentChild.unity";
            if (!File.Exists(path)) return;
            if (UnityEngine.SceneManagement.SceneManager.GetActiveScene().isDirty) return;
            EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
            EditorPrefs.SetBool(key, true);
        }
    }
}
