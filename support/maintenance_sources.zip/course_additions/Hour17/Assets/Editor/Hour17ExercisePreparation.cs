using System.IO;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

// Generates saved, editable AnimationClips and a scene. No runtime scene generator.
[InitializeOnLoad]
public static class Hour17ExercisePreparation
{
    const string Folder = "Assets/BookExercise17";
    const string ScenePath = "Assets/Scenes/Exercise.unity";
    const string Marker = Folder + "/Prepared.txt";
    static bool preparing;

    static Hour17ExercisePreparation() { EditorApplication.delayCall += PrepareIfMissing; }

    [MenuItem("Book/Hour 17/Create missing exercise assets")]
    public static void PrepareIfMissing()
    {
        if (preparing || File.Exists(Marker)) return;
        if (EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode)
        { EditorApplication.delayCall += PrepareIfMissing; return; }
        if (File.Exists(ScenePath)) return;
        preparing = true;
        Scene previous = SceneManager.GetActiveScene();
        Scene scene = default(Scene);
        bool completed = false;
        try
        {
            Directory.CreateDirectory(Folder);
            Directory.CreateDirectory("Assets/Scenes");
            AssetDatabase.Refresh();
            scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            SceneManager.SetActiveScene(scene);
            GameObject cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            cameraObject.AddComponent<Camera>().backgroundColor = new Color(.09f, .11f, .15f);
            cameraObject.AddComponent<AudioListener>();
            cameraObject.transform.position = new Vector3(0, 4, -13);
            cameraObject.transform.LookAt(new Vector3(0, 1, 0));
            GameObject lightObject = new GameObject("Directional Light");
            Light light = lightObject.AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1.1f;
            lightObject.transform.rotation = Quaternion.Euler(45, -25, 0);
            GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
            floor.name = "Floor";
            floor.transform.position = new Vector3(0, -.65f, 0);
            floor.GetComponent<Renderer>().sharedMaterial = Material("Floor", new Color(.22f, .25f, .3f));

            GameObject arc = Cube("Arc flight", new Vector3(-4, 0, 0), new Color(.2f, .8f, .5f));
            AnimationClip flight = Clip("ArcFlight", 4);
            Set(flight, typeof(Transform), "m_LocalPosition.x", new AnimationCurve(
                new Keyframe(0, -4), new Keyframe(1, -2), new Keyframe(2, 0), new Keyframe(3, -2), new Keyframe(4, -4)));
            Set(flight, typeof(Transform), "m_LocalPosition.y", new AnimationCurve(
                new Keyframe(0, 0), new Keyframe(1, 2.2f), new Keyframe(2, 3), new Keyframe(3, 2.2f), new Keyframe(4, 0)));
            Animate(arc, flight);

            GameObject blink = Cube("Renderer blinking", new Vector3(1.5f, 0, 0), new Color(1, .7f, .15f));
            AnimationClip blinking = Clip("RendererBlink", 2);
            AnimationCurve enabled = new AnimationCurve(new Keyframe(0, 1), new Keyframe(.5f, 0),
                new Keyframe(1, 1), new Keyframe(1.5f, 0), new Keyframe(2, 1));
            for (int i = 0; i < enabled.length; i++)
            {
                AnimationUtility.SetKeyLeftTangentMode(enabled, i, AnimationUtility.TangentMode.Constant);
                AnimationUtility.SetKeyRightTangentMode(enabled, i, AnimationUtility.TangentMode.Constant);
            }
            Set(blinking, typeof(MeshRenderer), "m_Enabled", enabled);
            Animate(blink, blinking);

            GameObject scale = Cube("Scale and material animation", new Vector3(4, 0, 0), Color.red);
            AnimationClip scaling = Clip("ScaleAndColor", 3);
            foreach (string axis in new string[] { "x", "y", "z" })
                Set(scaling, typeof(Transform), "m_LocalScale." + axis,
                    new AnimationCurve(new Keyframe(0, .6f), new Keyframe(1.5f, 1.4f), new Keyframe(3, .6f)));
            Set(scaling, typeof(MeshRenderer), "material._Color.r", new AnimationCurve(new Keyframe(0, 1), new Keyframe(1.5f, 0), new Keyframe(3, 1)));
            Set(scaling, typeof(MeshRenderer), "material._Color.g", new AnimationCurve(new Keyframe(0, 0), new Keyframe(1.5f, 1), new Keyframe(3, 0)));
            Set(scaling, typeof(MeshRenderer), "material._Color.b", new AnimationCurve(new Keyframe(0, 0), new Keyframe(1.5f, 1), new Keyframe(3, 0)));
            Set(scaling, typeof(MeshRenderer), "material._Color.a", AnimationCurve.Constant(0, 3, 1));
            Animate(scale, scaling);

            // Finish the Curves Editor practicum in the delivery copy.
            AnimationClip spin = AssetDatabase.LoadAssetAtPath<AnimationClip>("Assets/Animations/ObjectSpinAnim.anim");
            if (spin != null)
            {
                Set(spin, typeof(Transform), "localEulerAnglesRaw.y", AnimationCurve.Linear(0, 0, 1, 360));
                EditorUtility.SetDirty(spin);
            }
            EditorSceneManager.MarkSceneDirty(scene);
            if (!EditorSceneManager.SaveScene(scene, ScenePath))
                throw new System.IO.IOException("Could not save final exercise scene.");
            AssetDatabase.SaveAssets();
            AddBuildSceneFirst();
            File.WriteAllText(Marker, "Saved native final exercise; inspect Animation and Animator windows.\n");
            AssetDatabase.ImportAsset(Marker);
            completed = true;
        }
        finally
        {
            if (completed && scene.IsValid())
            {
                bool otherSceneDirty = false;
                for (int i = 0; i < SceneManager.sceneCount; i++)
                {
                    Scene openScene = SceneManager.GetSceneAt(i);
                    if (openScene.handle != scene.handle && openScene.isDirty) otherSceneDirty = true;
                }
                if (otherSceneDirty) SceneManager.SetActiveScene(scene);
                else EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
            }
            else
            {
                if (scene.IsValid()) EditorSceneManager.CloseScene(scene, true);
                if (previous.IsValid() && previous.isLoaded) SceneManager.SetActiveScene(previous);
            }
            preparing = false;
        }
    }

    static void AddBuildSceneFirst()
    {
        List<EditorBuildSettingsScene> scenes = new List<EditorBuildSettingsScene>();
        scenes.Add(new EditorBuildSettingsScene(ScenePath, true));
        foreach (EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
            if (scene.path != ScenePath) scenes.Add(scene);
        EditorBuildSettings.scenes = scenes.ToArray();
    }

    static Material Material(string name, Color color)
    {
        Material material = new Material(Shader.Find("Standard"));
        material.name = name;
        material.color = color;
        AssetDatabase.CreateAsset(material, Folder + "/" + name + ".mat");
        return material;
    }
    static GameObject Cube(string name, Vector3 position, Color color)
    {
        GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.name = name;
        cube.transform.position = position;
        cube.GetComponent<Renderer>().sharedMaterial = Material(name.Replace(" ", ""), color);
        return cube;
    }
    static AnimationClip Clip(string name, float duration)
    {
        AnimationClip clip = new AnimationClip();
        clip.name = name;
        clip.frameRate = 30;
        AnimationClipSettings settings = AnimationUtility.GetAnimationClipSettings(clip);
        settings.loopTime = true;
        settings.stopTime = duration;
        AnimationUtility.SetAnimationClipSettings(clip, settings);
        AssetDatabase.CreateAsset(clip, Folder + "/" + name + ".anim");
        return clip;
    }
    static void Set(AnimationClip clip, System.Type type, string property, AnimationCurve curve)
    { AnimationUtility.SetEditorCurve(clip, EditorCurveBinding.FloatCurve("", type, property), curve); }
    static void Animate(GameObject target, AnimationClip clip)
    {
        Animator animator = target.AddComponent<Animator>();
        AnimatorController controller = AnimatorController.CreateAnimatorControllerAtPath(Folder + "/" + clip.name + ".controller");
        controller.AddMotion(clip);
        animator.runtimeAnimatorController = controller;
        animator.applyRootMotion = false;
    }
}
