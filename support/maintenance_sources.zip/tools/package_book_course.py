#!/usr/bin/env python3
"""Package 24 complete chapter folders, preserving .meta and original image bytes."""
from pathlib import Path
import concurrent.futures,hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'release-course'

def package(hour):
    name=f'Hour{hour:02d}';folder=ROOT/'course'/name;target=OUT/(name+'.zip')
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(folder.rglob('*')):
            if p.is_file():z.write(p,Path(name)/p.relative_to(folder))
    with zipfile.ZipFile(target) as z:
        bad=z.testzip();assert bad is None,(name,bad)
        names=set(z.namelist());assert name+'/ProjectSettings/ProjectVersion.txt' in names
        assert any(n.startswith(name+'/Assets/') for n in names)
        assert not any('/Library/' in n for n in names)
    size=target.stat().st_size;assert size<100*1024*1024,(name,'GitHub file limit',size)
    chapter=json.loads((folder/'chapter.json').read_text())
    return {'hour':hour,'file':target.name,'bytes':size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'title':chapter['title'],'primary_scene':chapter['primary_scene'],'engine_checks':'UNRUN','editor_preparation_pending':hour in [17,19]}

def main():
    OUT.mkdir(exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(package,range(1,25)))
    (OUT/'manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
    rows='\n'.join(f"|{r['hour']:02d}|{r['title']}|[{r['file']}]({r['file']})|{r['bytes']/1024/1024:.1f}МБ|" for r in records)
    (OUT/'README.md').write_text('''# Unity2018.1.0f1 — проекты по24часам книги

[Скачать весь комплект одним ZIP](https://github.com/Shinshilow/uniytu/archive/refs/heads/book-course-2018.zip)

В комплекте24отдельных архива Hour01.zip…Hour24.zip. Каждый содержит папку с Assets и ProjectSettings, оригинальные ассеты книги и инструкцию ОТКРЫТЬ.md. Архив Unity.zip с материалами издательства получен из вашего релиза book-files; старые упрощённые комплекты здесь не используются.

## Как открыть без Unity Hub

1. Распакуйте общий ZIP, затем нужный HourNN.zip.
2. Запустите обычный Unity2018.1.0f1 → File → Open Project → выберите HourNN (папку с Assets и ProjectSettings).
3. Дождитесь импорта. Откроется основная сцена; её путь также записан в ОТКРЫТЬ.md. Если не открылась, найдите сцену в Project и откройте двойным щелчком.
4. Нажмите Play. Практикумы внутри главы доступны в Assets/Scenes и отдельном проекте Practice, если он есть.

## Что восстановлено и что ещё не проверено

Включены оригинальные материалы/normal maps, модели с UV, paintedTerrain, тайлы/палитры, RobotBoy, Ethan с Humanoid, звуки, анимации и игровые механики автора. Дополнены недостающие сцены и творческие задания. Исходные проекты издательства были2018.1.0b3/b4; рабочие копии подготовлены для2018.1.0f1.

Проверены структура24папок, реальные ссылки материалов/normal maps, бинарные TerrainData через запись+чтение, синтаксисC# по веткам Windows и целостность всех ZIP. **UnityEditor в облаке не запускался: импорт, компиляцияAPI, Play и EXE не проверены. Это исходные проекты, а не24готовыхEXE или подтверждённые работы для сдачи.**

Часы17/19 сохраняют недостающие упражнения редакторным дополнением при первом импорте; эта подготовка здесь ещё не исполнялась. Час15 требует реальных отзывов игроков,22—телефона/UnityRemote,23—реальной сборки и запуска. Час24 содержит HTML-разбор игры и проект для анализа; собственные наблюдения нужно добавить после запуска.

Собрать EXE на своём компьютере: Book → Build Windows x64. Нужен Windows Build Support версии2018.1.0f1. Результат Builds/HourNN — передавать всю папку с EXE, *_Data и DLL.

## Скачать отдельный час

Откройте файл архива ниже и нажмите Download raw file.

|Час|Тема|Архив|Размер|
|---|---|---|---|
'''+rows+'\n\nРазмеры и SHA256 — в manifest.json. Проверки и ограничения — в CHECKS.md.\n')
    checks=json.loads((ROOT/'audit/book-course-validation.json').read_text())
    (OUT/'CHECKS.md').write_text('''# Выполненные проверки

- 24папки Unity2018.1.0f1: Assets/ProjectSettings/сцены/инструкции.
- 80сохранённых сцен в основных проектах; остальные практикумы находятся в Practice.
- 93материала с реальными назначенными текстурами в основных проектах. Отдельные проекты Practice содержат дополнительные материалы.
- Час3: четыре кирпичных Standardматериала, две normal map с правильным импортом; час4: настоящий бинарный TerrainData, spatialalphas, деревья/трава и FPS; час20: оригинальная UV-прокрутка и материалы.
- Исправлены source-пропуски: один включённый AudioListener часа5; CompositeCollider часа13; Smoke часа16; стёрта старая пустая ссылка на отсутствующий Timeline-трек часа19.
- 590C#файлов прошли синтаксический разбор выбранной ветки WindowsEditor;488 — WindowsMonoPlayer. Это не компиляция с API.
- Все24ZIP проверены CRC; данные .meta сохранены. Исходный Unity.zip не изменялся.

Остаются неисполненными: Unity2018.1.0f1 import/APIcompile/Play/render/audio/physics, подготовка Editorупражнений17/19, реальные пользовательские/мобильные тесты и EXEсборки. Их нельзя считать прошедшими по файловым проверкам. В исходном архиве автора есть устаревшие ссылки в неиспользуемых вспомогательных StandardAssets; они отражены в аудитах и не выданы за доказанные runtimeошибки.
''')
    print('Packaged24ZIPs; total MB',round(sum(r['bytes'] for r in records)/1024/1024,1),'largest MB',round(max(r['bytes'] for r in records)/1024/1024,1))
if __name__=='__main__':main()
