#!/usr/bin/env python3
"""Assemble 24 chapter folders from publisher assets plus reviewed native practica.

Original archive stays read-only. Each HourNN root is an independent Unity project;
Practice is a separate optional project, outside root Assets (never compiled twice).
Unity runtime validation must be recorded separately.
"""
from pathlib import Path
import hashlib,json,re,shutil,importlib.util
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path('/workspace/book-originals/extracted')
DEST=ROOT/'course'
NATIVE={1,2,7,8,9,11,22,23}
# At first import, open an actual saved scene, never generate runtime geometry.
OPEN_SCRIPT='''using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using System.IO;
namespace BookCourse.Editor
{
    [InitializeOnLoad]
    public static class OpenChapter
    {
        static OpenChapter() { EditorApplication.delayCall += Open; }
        static void Open()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating) { EditorApplication.delayCall += Open; return; }
            string key = "BookCourse.Open.OriginalAssets.2026." + Application.dataPath;
            if (EditorPrefs.GetBool(key, false)) return;
            string path = "__SCENE__";
            if (!File.Exists(path)) return;
            if (UnityEngine.SceneManagement.SceneManager.GetActiveScene().isDirty) return;
            EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
            EditorPrefs.SetBool(key, true);
        }
    }
}
'''
BUILD_SCRIPT='''using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
namespace BookCourse.Editor
{
    public static class BuildWindows
    {
        [MenuItem("Book/Build Windows x64")]
        public static void Execute()
        {
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Standalone, BuildTarget.StandaloneWindows64))
                throw new InvalidOperationException("Install Windows Build Support for Unity 2018.1.0f1.");
            string[] scenes = EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path).ToArray();
            if (scenes.Length == 0) throw new InvalidOperationException("No scenes in Build Settings.");
            PlayerSettings.companyName = "Unity Book Study";
            PlayerSettings.productName = "__HOUR__";
            PlayerSettings.defaultScreenWidth = 1000;
            PlayerSettings.defaultScreenHeight = 700;
            string output = Path.GetFullPath("Builds/__HOUR__/__HOUR__.exe");
            Directory.CreateDirectory(Path.GetDirectoryName(output));
            var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions {
                scenes = scenes, locationPathName = output,
                target = BuildTarget.StandaloneWindows64, options = BuildOptions.None });
            if (report.summary.result != BuildResult.Succeeded)
                throw new Exception("Windows build failed: " + report.summary.result);
            Debug.Log("BOOK_BUILD_SUCCEEDED " + output);
        }
    }
}
'''

def guid(s):return hashlib.md5(('book-course/'+s).encode()).hexdigest()
def script_meta(p):
    Path(str(p)+'.meta').write_text('fileFormatVersion: 2\nguid: '+guid(str(p.relative_to(DEST)))+'\nMonoImporter:\n  externalObjects: {}\n  serializedVersion: 2\n  defaultReferences: []\n  executionOrder: 0\n  icon: {instanceID: 0}\n  userData:\n  assetBundleName:\n  assetBundleVariant:\n')
def source_hour(h):return next(p for p in SOURCE.iterdir() if p.name.lower().startswith(f'hour {h} files'))
def original_projects(h):return sorted(p for p in (source_hour(h)/'Completed Projects').iterdir() if p.is_dir())
def choose(h):
    projects=original_projects(h)
    return next((p for p in projects if 'exercise' in p.name.lower()),next((p for p in projects if 'diy' in p.name.lower()),projects[0]))
def copy_project(src,dst):
    dst.mkdir(parents=True,exist_ok=True)
    for name in ['Assets','ProjectSettings']:
        shutil.copytree(src/name,dst/name,dirs_exist_ok=True)
    # Deliberately exclude Library, Temp and beta UnityPackageManager binaries.
    if (src/'ОТКРЫТЬ.md').exists():shutil.copy2(src/'ОТКРЫТЬ.md',dst/'DETAILS.md')
    for name in ['scene_manifest.json','Build-Windows.ps1']:
        if (src/name).exists():shutil.copy2(src/name,dst/name)
    (dst/'ProjectSettings/ProjectVersion.txt').write_text('m_EditorVersion: 2018.1.0f1\n')
    (dst/'.gitignore').write_text('Library/\nTemp/\nObj/\nLogs/\nBuilds/\n*.csproj\n*.sln\n')

def startup(h,project):
    scenes=sorted((project/'Assets').rglob('*.unity'))
    def score(p):
        name=p.stem.lower()
        if name.startswith('exercise'):return 0
        if h==1 and name=='03_exercise_cube':return 0
        if h==2 and name=='03_exercise_parentchild':return 0
        if h==7 and name.startswith('04_exercise'):return 0
        if h==8 and name.startswith('07_exercise'):return 0
        if h==9 and name.startswith('06_exercise'):return 0
        if h==11 and name.startswith('06_exercise'):return 0
        if h==22 and name.startswith('04_exercise'):return 0
        if h==23 and name=='scene1':return 0
        if h==14 and name=='menu':return 0
        if name=='main':return 1
        if h==19 and name=='scripting':return 1
        return 5
    return sorted(scenes,key=lambda p:(score(p),str(p)))[0] if scenes else None

def configure(h,project):
    primary=startup(h,project)
    if primary is None:return None
    scenes=sorted((project/'Assets').rglob('*.unity'))
    # Exact Scene1/Scene2 indices are part of chapter23.
    scenes=[primary]+[p for p in scenes if p!=primary]
    if h==23:
        second=next((p for p in scenes if p.stem=='Scene2'),None)
        if second:scenes=[primary,second]+[p for p in scenes if p not in [primary,second]]
    if h==14:
        second=next((p for p in scenes if p.stem=='Game'),None)
        if second:scenes=[primary,second]+[p for p in scenes if p not in [primary,second]]
    settings='%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n--- !u!1045 &1\nEditorBuildSettings:\n  m_ObjectHideFlags: 0\n  serializedVersion: 2\n  m_Scenes:\n'
    for scene in scenes:
        meta=Path(str(scene)+'.meta');g=re.search(r'^guid: (\w+)',meta.read_text(),re.M).group(1)
        settings+='  - enabled: 1\n    path: '+scene.relative_to(project).as_posix()+'\n    guid: '+g+'\n'
    (project/'ProjectSettings/EditorBuildSettings.asset').write_text(settings+'  m_configObjects: {}\n')
    editor=project/'Assets/BookCourse/Editor';editor.mkdir(parents=True,exist_ok=True)
    for name,content in [('OpenChapter.cs',OPEN_SCRIPT.replace('__SCENE__','Assets/Scenes/Exercise.unity' if h in [17,19] and project.name==f'Hour{h:02d}' else primary.relative_to(project).as_posix())),('BuildWindows.cs',BUILD_SCRIPT.replace('__HOUR__',f'Hour{h:02d}'))]:
        p=editor/name;p.write_text(content);script_meta(p)
    return primary.relative_to(project).as_posix()

def main():
    if DEST.exists():
        if not (DEST/'manifest.json').exists(): raise RuntimeError('Refuse to replace unknown course directory.')
        shutil.rmtree(DEST)
    DEST.mkdir(exist_ok=True);requirements=json.loads((ROOT/'audit/book-requirements.json').read_text())['hours'];records=[]
    for h in range(1,25):
        d=DEST/f'Hour{h:02d}';publisher=choose(h if h<24 else 20)
        base=(ROOT/'rebuild'/f'Hour{h:02d}') if h in NATIVE else publisher
        copy_project(base,d)
        practice=next((p for p in original_projects(h if h<24 else 20) if 'tiy' in p.name.lower()),None)
        if practice and (h in NATIVE or practice != base):
            copy_project(practice,d/'Practice');configure(h,d/'Practice')
        elif h in NATIVE:
            copy_project(publisher,d/'PublisherExample');configure(h,d/'PublisherExample')
        if h in NATIVE and 'exercise' in publisher.name.lower():
            copy_project(publisher,d/'PublisherExercise');configure(h,d/'PublisherExercise')
        # Preserve loose original import files outside Assets; no duplicate scripts.
        if h<24:
            for path in source_hour(h).iterdir():
                if path.name=='Completed Projects':continue
                target=d/'SourceFiles'/path.name;target.parent.mkdir(exist_ok=True)
                if path.is_dir():shutil.copytree(path,target,dirs_exist_ok=True)
                else:shutil.copy2(path,target)
        overlay=ROOT/'course_additions'/f'Hour{h:02d}'
        if overlay.exists():shutil.copytree(overlay,d,dirs_exist_ok=True)
        primary=configure(h,d)
        record={'hour':h,'title':requirements[h-1]['title'],'publisher_base':str(publisher.relative_to(SOURCE)),'primary_base':'native-reviewed' if h in NATIVE else 'publisher','primary_scene':primary,'original_assets':True,'engine_import':'UNRUN','engine_compilation':'UNRUN','play':'UNRUN','windows_build':'UNRUN'}
        records.append(record)
        readme=f'''# Час {h:02d} — {record['title']}

Unity **2018.1.0f1**, Unity Hub не требуется.

1. Полностью распакуйте Hour{h:02d}.zip.
2. В Unity выберите File → Open Project → папку Hour{h:02d}, где лежат Assets и ProjectSettings.
3. При первом импорте откроется сохранённая сцена `{primary}`. Если не открылась, найдите этот файл в Project и откройте двойным щелчком.
4. Нажмите Play; управление и смысл заданий — в перечисленных сценах/скриптах и карте требований.

Папка Practice (если есть) — отдельный проект с оригинальными практикумами издательства. Открывать через File → Open Project → Practice. Сцены находятся в её Assets/Scenes. Это не набор скриптов для копирования в основной Assets.

SourceFiles содержит исходные текстуры/модели/аудио для ручного импорта из архива книги. PublisherExercise/PublisherExample (если есть) сохраняют отдельно исходный вариант автора для сравнения. DETAILS.md содержит более подробное сопоставление дополненных практикумов (когда такой файл есть).

## Проверки и ограничения

Ассеты взяты из предоставленного вами Unity.zip, оригинальные .meta/GUID и модели с UV сохранены. Кэши beta-редактора исключены. Исходные проекты были 2018.1.0b3/b4; в рабочих копиях указан2018.1.0f1. Импорт/компиляция Unity API, Play и сборка EXE в этой облачной среде пока не выполнены. Проверки файлов не заменяют запуск; готовность к сдаче этим не подтверждается.

Сборка на вашем компьютере: Book → Build Windows x64 (нужен Windows Build Support той же версии). Выход: Builds/Hour{h:02d}/Hour{h:02d}.exe. Передавайте всю папку вместе с *_Data и DLL. EXE в этом архиве нет.

Оригинальная база: `{record['publisher_base']}`. Дополнительные реализации заданий отмечены отдельно; они не выдаются за авторские файлы издательства. Плейтесты и работу на телефоне нужно проводить реально; выдуманных результатов здесь нет.
'''
        (d/'ОТКРЫТЬ.md').write_text(readme)
        (d/'chapter.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    (DEST/'manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
    print('Assembled 24 chapter folders; engine checks UNRUN.')
if __name__=='__main__':main()
