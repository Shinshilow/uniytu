#!/usr/bin/env python3
"""Parse selected Unity2018 Windows preprocessor branches. Not API compilation."""
from pathlib import Path
import re,json
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
ROOT=Path(__file__).resolve().parents[1]
BASE={'UNITY_2018','UNITY_2018_1','UNITY_2018_1_OR_NEWER','UNITY_2017_1_OR_NEWER','UNITY_2017_2_OR_NEWER','UNITY_2017_3_OR_NEWER','UNITY_5_3_OR_NEWER','UNITY_5_4_OR_NEWER','UNITY_5_5_OR_NEWER','UNITY_5_6_OR_NEWER','UNITY_STANDALONE','UNITY_STANDALONE_WIN','ENABLE_MONO'}
def preprocess(source,symbols):
    symbols=set(symbols);stack=[];active=True;output=[]
    def expression(expr):
        expr=expr.split('//',1)[0].strip()
        if not re.fullmatch(r'[A-Za-z0-9_!&|=()\s]+',expr):raise ValueError('Unsupported directive: '+expr)
        expr=re.sub(r'\b[A-Za-z_]\w*\b',lambda m:'True' if m[0]=='true' or m[0] in symbols else 'False',expr)
        expr=expr.replace('&&',' and ').replace('||',' or ');expr=re.sub(r'!(?!=)',' not ',expr)
        return bool(eval(expr.strip(),{'__builtins__':{}},{}))
    for line in source.splitlines():
        m=re.match(r'^\s*#(if|elif|else|endif|define|undef)\b\s*(.*)',line)
        if not m:output.append(line if active else '');continue
        command,value=m.groups()
        if command=='if':
            selected=expression(value);stack.append([active,selected]);active=active and selected
        elif command=='elif':
            parent,taken=stack[-1];selected=not taken and expression(value);stack[-1][1]=taken or selected;active=parent and selected
        elif command=='else':
            parent,taken=stack[-1];active=parent and not taken;stack[-1][1]=True
        elif command=='endif':active=stack.pop()[0]
        elif command=='define' and active:symbols.add(value.strip())
        elif command=='undef' and active:symbols.discard(value.strip())
        output.append('')
    assert not stack
    return '\n'.join(output)
def main():
    parser=Parser(Language(tree_sitter_c_sharp.language()));results=[]
    for profile,symbols in [('Windows Editor',BASE|{'UNITY_EDITOR','UNITY_EDITOR_WIN'}),('Windows Mono Player',BASE)]:
        errors=[];count=0
        for f in sorted((ROOT/'course').rglob('*.cs')):
            if profile=='Windows Mono Player' and any(p.lower()=='editor' for p in f.parts):continue
            count+=1;text=f.read_text(encoding='utf-8-sig')
            tree=parser.parse(preprocess(text,symbols).encode())
            if tree.root_node.has_error:errors.append(str(f.relative_to(ROOT)))
        results.append({'profile':profile,'files_parsed':count,'syntax_errors':errors,'unity_api_compilation':'UNRUN'})
    (ROOT/'audit/book-course-csharp-syntax.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(results,ensure_ascii=False))
    if any(r['syntax_errors'] for r in results):raise SystemExit(1)
if __name__=='__main__':main()
