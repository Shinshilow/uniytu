#!/usr/bin/env python3
"""Apply explicit book corrections/additional stages to working copies only."""
from pathlib import Path
import json,re,shutil,hashlib
import yaml
import assemble_book_course as assembly
import build_native_intro as native
from build_native_scripting import attach_camera
ROOT=Path(__file__).resolve().parents[1];COURSE=ROOT/'course';native.OUT=COURSE
RX=re.compile(r'^--- !u!(\d+) &(\d+).*$',re.M)
def blocks(text):
    matches=list(RX.finditer(text));result=[]
    for i,m in enumerate(matches):
        end=matches[i+1].start() if i+1<len(matches) else len(text)
        raw=text[m.start():end];data=yaml.safe_load(text[m.end():end]);result.append((int(m[1]),int(m[2]),raw,data))
    return result

def change(path,fn):
    text=path.read_text();bs=blocks(text);header=text[:RX.search(text).start()];path.write_text(header+''.join(fn(kind,ident,raw,data) for kind,ident,raw,data in bs))
def meta(path):
    g=assembly.guid(str(path.relative_to(COURSE)));Path(str(path)+'.meta').write_text('fileFormatVersion: 2\nguid: '+g+'\nDefaultImporter:\n  externalObjects: {}\n  userData:\n  assetBundleName:\n  assetBundleVariant:\n');return g

def clone_scene(src,target):shutil.copy2(src,target);meta(target)
def compid(c):return c.get('component',next(iter(c.values())))['fileID']
def getguid(path):return re.search(r'^guid:\s*(\w+)',Path(str(path)+'.meta').read_text(),re.M)[1]
def generic_prefab_instance(prefab,i,pos,name,order=10):
    data=blocks(prefab.read_text());docs={ident:doc for _,ident,_,doc in data};pid=next(ident for kind,ident,_,_ in data if kind==1001)
    go=docs[pid]['Prefab']['m_RootGameObject']['fileID'];transform=next(compid(c) for c in docs[go]['GameObject']['m_Component'] if 'Transform' in docs[compid(c)])
    g=getguid(prefab);mods=''
    for path,value,target in [('m_LocalPosition.x',pos[0],transform),('m_LocalPosition.y',pos[1],transform),('m_LocalPosition.z',pos[2],transform),('m_RootOrder',order,transform),('m_Name',name,go)]:
        mods+=f'    - target: {{fileID: {target}, guid: {g}, type: 2}}\n      propertyPath: {path}\n      value: {value}\n      objectReference: {{fileID: 0}}\n'
    return f'''--- !u!1001 &{i}
Prefab:
  m_ObjectHideFlags: 0
  serializedVersion: 2
  m_Modification:
    m_TransformParent: {{fileID: 0}}
    m_Modifications:
'''+mods+f'''    m_RemovedComponents: []
  m_ParentPrefab: {{fileID: {pid}, guid: {g}, type: 2}}
  m_IsPrefabParent: 0
--- !u!4 &{i+1} stripped
Transform:
  m_PrefabParentObject: {{fileID: {transform}, guid: {g}, type: 2}}
  m_PrefabInternal: {{fileID: {i}}}
'''

def hour5():
    p=COURSE/'Hour05';scene=p/'Assets/Scenes/Main.unity';enabled=[False]
    def listeners(kind,ident,raw,data):
        if kind==81:
            raw=re.sub(r'm_Enabled: \d','m_Enabled: '+('1' if not enabled[0] else '0'),raw);enabled[0]=True
        return raw
    change(scene,listeners)
    practice=p/'Practice/Assets/Scenes';halo=practice/'Halo.unity';clone_scene(practice/'Point Light.unity',halo)
    change(halo,lambda kind,ident,raw,data:raw.replace('m_DrawHalo: 0','m_DrawHalo: 1') if kind==108 else raw)
    depth=practice/'Two Cameras Depth.unity';clone_scene(practice/'Multiple Cameras.unity',depth);first=[True]
    def depthfields(kind,ident,raw,data):
        if kind==20:
            raw=re.sub(r'm_Depth: [-\d.]+','m_Depth: '+('1' if first[0] else '0'),raw)
            raw=re.sub(r'(m_NormalizedViewPortRect:\n\s*serializedVersion: \d+\n\s*x:) [^\n]+\n\s*y: [^\n]+\n\s*width: [^\n]+\n\s*height: [^\n]+',r'\1 0\n    y: 0\n    width: 1\n    height: 1',raw)
            first[0]=False
        return raw
    change(depth,depthfields);assembly.configure(5,p/'Practice')

def hour7():
    p=COURSE/'Hour07';original=p/'Practice/Assets/Scripts';dest=p/'Assets/PublisherExamples';dest.mkdir(exist_ok=True)
    examples=['EqualityAndOperations','Loops','Conditionals','VariableScript']
    for i,name in enumerate(examples):
        source=original/(name+'.cs');target=dest/source.name;shutil.copy2(source,target);shutil.copy2(Path(str(source)+'.meta'),Path(str(target)+'.meta'))
        native.save_scene(p,'03'+chr(ord('b')+i)+'_Publisher_'+name,attach_camera([getguid(target)]))
    note='\nОригинальные примеры издательства теперь включены в Assets/PublisherExamples и четыре отдельные сцены03b–03e; EqualityAndOperations.cs больше не отсутствует. Сохраняются также независимые практикумы по переводу книги.\n'
    with (p/'ОТКРЫТЬ.md').open('a') as f:f.write(note)
    if (p/'DETAILS.md').exists():
        with (p/'DETAILS.md').open('a') as f:f.write(note)

def hour9():
    p=COURSE/'Hour09';src=next(assembly.source_hour(10).glob('Completed Projects/*/Assets/Standard Assets/PhysicsMaterials'));dest=p/'Assets/OriginalPhysicsMaterials';shutil.copytree(src,dest,dirs_exist_ok=True)
    mapping={'Authored_BouncyStudy':'Bouncy','Authored_IceStudy':'Ice','Authored_MetalStudy':'Metal','Authored_RubberStudy':'Rubber','Authored_TreeStudy':'Wood'}
    refs={}
    for a,b in mapping.items():
        authored=next((p/'Assets/PhysicsMaterials').glob(a+'.physicMaterial'));original=next(x for x in dest.iterdir() if x.stem==b and x.suffix.lower()=='.physicmaterial');refs[getguid(authored)]=getguid(original)
    for old,new in [('03a_AuthoredPhysicMaterials_Friction','03c_OriginalPhysicMaterials_Friction'),('03b_AuthoredPhysicMaterials_Bounce','03d_OriginalPhysicMaterials_Bounce')]:
        target=p/'Assets/Scenes'/(new+'.unity');clone_scene(p/'Assets/Scenes'/(old+'.unity'),target);text=target.read_text()
        for a,b in refs.items():text=text.replace(a,b)
        target.write_text(text)
    note='\nОригинальные PhysicsMaterials из предоставленного архива добавлены в Assets/OriginalPhysicsMaterials. Сцены03c/03d используют настоящие Bouncy,Ice,Metal,Rubber,Wood из Standard Assets. Сцены03a/03b оставлены как отдельные собственные эксперименты, их не следует путать с оригиналами.\n'
    for filename in ['ОТКРЫТЬ.md','DETAILS.md']:
        if (p/filename).exists():
            with (p/filename).open('a') as f:f.write(note)

def hour13():
    scene=COURSE/'Hour13/Assets/Scenes/Main.unity'
    def fix(kind,ident,raw,data):
        return raw.replace('m_UsedByComposite: 0','m_UsedByComposite: 1') if 'TilemapCollider2D' in data and ident==586025270 else raw
    change(scene,fix)

def hour16():
    p=COURSE/'Hour16';smoke=next(p.glob('Assets/**/Smoke.prefab'));scene=p/'Assets/Scenes/Main.unity';text=scene.read_text()
    if getguid(smoke) not in text:
        i=max(int(m[2]) for m in RX.finditer(text))+1000
        scene.write_text(text+generic_prefab_instance(smoke,i,(2,0,0),'Smoke',20))

def clone_subtree(scene,rootgo,newname,position):
    text=scene.read_text();bs=blocks(text);docs={i:d for _,i,_,d in bs};raws={i:r for _,i,r,_ in bs};root=docs[rootgo]['GameObject'];trans=next(compid(c) for c in root['m_Component'] if 'Transform' in docs[compid(c)]);wanted=set()
    def collect(go):
        wanted.add(go)
        for c in docs[go]['GameObject']['m_Component']:
            cid=compid(c);wanted.add(cid)
            if 'Transform' in docs[cid]:
                for child in docs[cid]['Transform']['m_Children']:collect(docs[child['fileID']]['Transform']['m_GameObject']['fileID'])
    collect(rootgo);start=max(docs)+10000;lookup={old:start+n for n,old in enumerate(sorted(wanted))}
    result=''
    for old in sorted(wanted):
        raw=raws[old];raw=re.sub(r'^--- !u!(\d+) &\d+',lambda m:'--- !u!'+m[1]+' &'+str(lookup[old]),raw)
        raw=re.sub(r'\{fileID: (-?\d+)([^}]*)\}',lambda m:'{fileID: '+str(lookup.get(int(m[1]),int(m[1])))+m[2]+'}' if 'guid:' not in m[2] else m[0],raw)
        if old==rootgo:raw=re.sub(r'^  m_Name: .*$', '  m_Name: '+newname,raw,flags=re.M)
        if old==trans:raw=re.sub(r'm_LocalPosition: \{[^}]+\}','m_LocalPosition: '+native.vec(position),raw)
        result+=raw
    scene.write_text(text+result)

def hour6():
    p=COURSE/'Hour06';main=p/'Assets/Scenes/Main.unity';target=p/'Assets/Scenes/Exercise Alternate Finish.unity';clone_scene(main,target)
    bs=blocks(target.read_text());docs={i:d for _,i,_,d in bs}
    # Locate actual book FinishZone component and clone its complete object.
    script=next(p.glob('Assets/**/FinishZone.cs'));g=getguid(script)
    component=next(data['MonoBehaviour'] for kind,_,_,data in bs if kind==114 and data['MonoBehaviour']['m_Script'].get('guid')==g)
    go=component['m_GameObject']['fileID'];transform=next(docs[compid(c)]['Transform'] for c in docs[go]['GameObject']['m_Component'] if 'Transform' in docs[compid(c)]);pos=transform['m_LocalPosition'];new=(pos['x']+12,pos['y'],pos['z'])
    clone_subtree(target,go,'Alternate Finish',new)
    (p/'EXERCISE.md').write_text('Итоговая творческая модификация часа6: отдельная сцена Exercise Alternate Finish с двумя независимыми финишными зонами и оригинальным игровым миром/текстурами. Новая зона смещена на12единицX от исходной. Деревья Terrain добавлены отдельным дополнением без изменения авторского маршрута. Путь и доступность второго финиша нужно проверить в Play; это не заявлено как выполненный тест.\n')

def hour20():
    p=COURSE/'Hour20/Assets/Scripts/GameManager.cs';s=p.read_text(encoding='utf-8-sig')
    s=s.replace('using UnityEngine;','using UnityEngine;\nusing UnityEngine.SceneManagement;',1)
    s=s.replace('float totalTimeElapsed = 0;','float totalTimeElapsed = 0;\n    float distance = 0;\n    public float virtualForwardSpeed = 20f;\n    void Awake() { Time.timeScale = 1f; }')
    s=s.replace('void Update()\n\t{','void Update()\n\t{\n        if (Input.GetKeyDown(KeyCode.R)) { Time.timeScale = 1f; SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex); return; }')
    s=s.replace('totalTimeElapsed += Time.deltaTime;','totalTimeElapsed += Time.deltaTime;\n        distance += virtualForwardSpeed * Time.deltaTime;')
    s=s.replace('void OnGUI()\n\t{','void OnGUI()\n\t{\n        GUI.Label(new Rect(10, 10, 400, 30), "Distance: " + distance.ToString("F1") + "    R: restart");')
    p.write_text(s)
    (COURSE/'Hour20/EXERCISE.md').write_text('Творческое дополнение часа20: HUD виртуальной пройденной дистанции (скорость20ед/с соответствует исходной скорости препятствий) и перезапускR. Оригинальные материалы Hologram/PhasedOut, TextureScroller, анимация, таймер10с, бонус+1.5 и штраф-0.5 сохранены. Реальный Play/баланс/сборка не проверены.\n')



def hour15():
    source=COURSE/'Hour15/Assets/Scripts/GameManager.cs'
    text=source.read_text(encoding='utf-8-sig')
    if 'SceneManager.LoadScene' not in text:
        text=text.replace('using UnityEngine;', 'using UnityEngine;\nusing UnityEngine.SceneManagement;',1)
        text=text.replace('int playerScore = 0;', 'int playerScore = 0;\n    void Awake() { Time.timeScale = 1f; }\n    void Update() { if (Input.GetKeyDown(KeyCode.R)) { Time.timeScale = 1f; SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex); } }')
        source.write_text(text)

def hour19():
    # The publisher serialized an orphan Timeline track binding to a missing
    # asset; its value is null. Remove only that stale pair in delivered copies.
    for scene in (COURSE/'Hour19/Assets/Scenes').glob('*.unity'):
        text=scene.read_text()
        text=re.sub(r'  - key: \{fileID: [-\d]+, guid: 155288b2422ec8f47be05ab7a96973e2, type: 2\}\n    value: \{fileID: 0\}\n','',text)
        scene.write_text(text)

def main():
    hour5();hour7();hour9();hour13();hour15();hour16();hour6();hour19();hour20()
    for h in range(1,25):
        project=COURSE/f'Hour{h:02d}';assembly.configure(h,project)
    print('Book corrections and explicit additions applied to working copies.')
if __name__=='__main__':main()
