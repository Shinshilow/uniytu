#!/usr/bin/env python3
"""Add the book's few Conifer trees to the original Amazing Racer TerrainData.

Only the native tree database changes; publisher heightmap, texture splats,
alpha texture bytes, terrain dimensions and asset GUID remain identical.
"""
from __future__ import annotations

import copy
import hashlib
import json
import random
import sys
from pathlib import Path

try:
    import UnityPy
except ImportError:
    sys.path.insert(0, "/tmp/unitypy-reader")
    import UnityPy

ROOT = Path(__file__).resolve().parents[1]
ORIGINALS = Path("/workspace/book-originals/extracted")
SOURCE = ORIGINALS / "Hour 6 Files Final/Completed Projects/Amazing Racer"
TREES = ORIGINALS / "Hour 4 Files final/Completed Projects/Hour 4 TIY/Assets/Terrains/Trees and Grass.asset"
DEST = ROOT / "course_additions/Hour06"
REL = Path("Assets/Terrains/New Terrain.asset")


def build() -> dict:
    original = SOURCE / REL
    original_hash = hashlib.sha256(original.read_bytes()).hexdigest()
    env = UnityPy.load(str(original))
    terrain = next(obj for obj in env.objects if obj.type.name == "TerrainData")
    data = terrain.read_typetree()
    old_data = copy.deepcopy(data)
    alpha = next(obj for obj in env.objects if obj.type.name == "Texture2D")
    old_alpha = alpha.get_raw_data()
    image = alpha.read().image
    tree_env = UnityPy.load(str(TREES))
    template = next(obj for obj in tree_env.objects if obj.type.name == "TerrainData")
    tree_data = template.read_typetree()["m_DetailDatabase"]
    conifer = copy.deepcopy(tree_data["m_TreePrototypes"][0])
    # Append the original real Conifer_Desktop external identifier, preserving
    # all four existing texture file IDs and their GUID bytes.
    reference = copy.deepcopy(template.assets_file.externals[conifer["prefab"]["m_FileID"] - 1])
    terrain.assets_file.externals.append(reference)
    conifer["prefab"]["m_FileID"] = len(terrain.assets_file.externals)
    database = data["m_DetailDatabase"]
    database["m_TreePrototypes"] = [conifer]
    heights = data["m_Heightmap"]["m_Heights"]
    rng = random.Random(606)
    positions = []
    for _ in range(10000):
        x, z = rng.uniform(.1, .9), rng.uniform(.1, .9)
        ix, iz = round(x * 512), round(z * 512)
        y = heights[iz * 513 + ix] / 32766
        # Far from the author's central route; only the real grass texture.
        if abs(x - .5) > .25 and y > .08 and image.getpixel((round(x * 511), 511 - round(z * 511)))[0] > 220:
            if all((x - a) ** 2 + (z - b) ** 2 > .006 for a, b in positions):
                positions.append((x, z))
        if len(positions) == 8:
            break
    assert len(positions) == 8
    database["m_TreeInstances"] = []
    for x, z in positions:
        instance = copy.deepcopy(tree_data["m_TreeInstances"][0])
        instance["position"] = {"x": x, "y": heights[round(z * 512) * 513 + round(x * 512)] / 32766, "z": z}
        instance["index"] = 0
        instance["widthScale"] = instance["heightScale"] = .23 + .05 * rng.random()
        database["m_TreeInstances"].append(instance)
    terrain.save_typetree(data)
    output = DEST / REL
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(env.file.save())
    output.with_name(output.name + ".meta").write_bytes(original.with_name(original.name + ".meta").read_bytes())
    check = UnityPy.load(str(output))
    actual = next(obj for obj in check.objects if obj.type.name == "TerrainData")
    actual_data = actual.read_typetree()
    assert actual_data["m_Heightmap"] == old_data["m_Heightmap"]
    assert actual_data["m_SplatDatabase"] == old_data["m_SplatDatabase"]
    assert next(obj for obj in check.objects if obj.type.name == "Texture2D").get_raw_data() == old_alpha
    assert len(actual_data["m_DetailDatabase"]["m_TreeInstances"]) == 8
    assert len(actual.assets_file.externals) == 5
    assert actual.assets_file.externals[-1].guid == reference.guid
    assert hashlib.sha256(original.read_bytes()).hexdigest() == original_hash
    report = {
        "status": "PASS_STATIC_AND_SERIALIZATION_ROUNDTRIP", "unity_editor_run": False,
        "source_unchanged_sha256": original_hash, "terrain": REL.as_posix(),
        "asset_guid_preserved": True, "original_heightmap_splats_and_alpha_bytes_identical": True,
        "terrain_size_preserved": [200, 100, 200], "native_tree_instances": 8,
        "tree_prototype": "Original Conifer_Desktop from the book; identical asset GUID exists in Hour06",
        "tree_positions_world": [[round(x * 200, 2), round(heights[round(z * 512) * 513 + round(x * 512)] / 32766 * 100, 2), round(z * 200, 2)] for x, z in positions],
        "route_preserved": "Trees placed on GrassHill areas >50 units from the central x=100 route; original route objects unchanged",
        "limitations": "Editor import/rendering and gameplay remain unrun. Grass detail layers were not added: the book asks for a few trees here."
    }
    (DEST / "HOUR06-TREES.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    return report


if __name__ == "__main__":
    print(json.dumps(build(), indent=2, ensure_ascii=False))
