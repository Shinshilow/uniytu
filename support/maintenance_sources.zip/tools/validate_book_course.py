#!/usr/bin/env python3
"""Validate distribution structure and actual mapping links; never claim Unity execution."""
from pathlib import Path
import json,re,sys
from inspect_unity_assets import inspect
from complete_book_course import blocks,compid
ROOT=Path(__file__).resolve().parents[1];C=ROOT/'course'

def main():
    manifest=json.loads((C/'manifest.json').read_text());assert [r['hour'] for r in manifest]==list(range(1,25))
    reports=[];fatal=[]
    for r in manifest:
        h=r['hour'];p=C/f'Hour{h:02d}'
        assert (p/'Assets').is_dir() and (p/'ProjectSettings').is_dir()
        assert (p/'ProjectSettings/ProjectVersion.txt').read_text().strip()=='m_EditorVersion: 2018.1.0f1'
        assert (p/'ОТКРЫТЬ.md').exists()
        actual=inspect(p)
        if actual['duplicate_guids']:fatal.append([h,'duplicateGUID',actual['duplicate_guids']])
        pending=h in [17,19]
        assert pending or (p/r['primary_scene']).is_file(),r
        assert not (p/'Library').exists()
        # Serialized references are checked for delivered scenes. Missing refs in
        # unused publisher optional prefabs are retained as warnings, not hidden.
        scene_missing=[x for x in actual['unresolved_guids'] if x['file'].endswith('.unity')]
        if scene_missing:fatal.append([h,'scene_missingGUID',scene_missing])
        report={'hour':h,'saved_scenes':len(actual['scenes']),'materials':len(actual['materials']),'mapped_materials':actual['textured_materials'],'normal_materials':actual['normal_materials'],'pending_editor_preparation':pending,'unresolved_non_scene_source_references':actual['unresolved_guids'],'engine_import':'UNRUN','engine_compilation':'UNRUN','play':'UNRUN','windows_build':'UNRUN'}
        reports.append(report)
    # Regressions reported by user, tested directly against real asset pointers.
    three=inspect(C/'Hour03');assert len(three['materials'])==4 and three['textured_materials']==4 and three['normal_materials']==2
    assert all(m['maps']['_MainTex']['asset'] for m in three['materials'])
    assert all(m['maps']['_BumpMap']['normal_import'] for m in three['materials'] if '_BumpMap' in m['maps'])
    five=blocks((C/'Hour05/Assets/Scenes/Main.unity').read_text());assert sum(d['AudioListener']['m_Enabled'] for k,i,t,d in five if k==81)==1
    thirteen=blocks((C/'Hour13/Assets/Scenes/Main.unity').read_text());assert next(d['TilemapCollider2D']['m_UsedByComposite'] for k,i,t,d in thirteen if i==586025270)==1
    sixteen=C/'Hour16';smoke=next(sixteen.glob('Assets/**/Smoke.prefab'));g=re.search(r'^guid: (\w+)',Path(str(smoke)+'.meta').read_text(),re.M)[1];assert g in (sixteen/'Assets/Scenes/Main.unity').read_text()
    assert (C/'Hour24/Разбор игры.html').exists()
    result={'chapters':reports,'fatal':fatal,'real_mapping_regressions':'PASS','unity_checks':'UNRUN'}
    (ROOT/'audit/book-course-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('24 chapter structures checked; real Hour03 maps+normals, Hour05 listener, Hour13 composite, Hour16 Smoke: PASS.')
    print('Saved primary project scenes:',sum(x['saved_scenes'] for x in reports),'mappedmaterials:',sum(x['mapped_materials'] for x in reports),'editor preparation pending17/19; allUnity checks UNRUN.')
    if fatal:
        print(json.dumps(fatal,ensure_ascii=False,indent=2));raise SystemExit(1)
if __name__=='__main__':main()
