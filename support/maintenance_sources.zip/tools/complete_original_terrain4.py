#!/usr/bin/env python3
"""Add the book's Hour 4 final exercise to the unmodified publisher project.

The publisher's real TerrainData, splat texture references, Conifer prototypes
and GrassFrond prototype are retained.  UnityPy is only a serialization tool:
no runtime or import-time scene factory is added to the Unity project.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import random
import re
import sys
from pathlib import Path

try:
    import UnityPy
except ImportError:
    sys.path.insert(0, "/tmp/unitypy-reader")
    import UnityPy

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path("/workspace/book-originals/extracted/Hour 4 Files final/Completed Projects/Hour 4 TIY")
DEST = ROOT / "course_additions/Hour04"
TERRAIN_REL = Path("Assets/Terrains/Exercise Beach Mountains Plain.asset")
SCENE_REL = Path("Assets/Scenes/Exercise Beach Mountains Plain.unity")
TERRAIN_GUID = hashlib.md5(b"original-book/Hour04/final-terrain").hexdigest()
SCENE_GUID = hashlib.md5(b"original-book/Hour04/final-scene").hexdigest()
N, MAX_H = 513, 60.0
HEIGHT_DENOMINATOR = 32766  # Verified against the publisher's patch bounds.


def smooth(a: float, b: float, value: float) -> float:
    t = max(0.0, min(1.0, (value - a) / (b - a)))
    return t * t * (3.0 - 2.0 * t)


def elevation(x: float, z: float) -> float:
    # Wide level beach; a smooth rocky transition; an exactly flat meadow.
    shore = 2.3 + 0.13 * math.sin(x * 4 * math.pi) * (1 - smooth(.14, .24, z))
    base = shore + (8.0 - shore) * smooth(.20, .35, z)
    # Joined mountain peaks make one ridge across the northern third.
    ridge_z = .81 + .025 * math.sin(x * 2 * math.pi)
    cross = math.exp(-((z - ridge_z) / .095) ** 2)
    peaks = 27 + 12 * math.sin(x * 3 * math.pi) ** 2
    mountains = cross * peaks * smooth(.60, .72, z)
    return base + mountains


def make_heights() -> list[int]:
    return [round(elevation(x / (N - 1), z / (N - 1)) / MAX_H * HEIGHT_DENOMINATOR)
            for z in range(N) for x in range(N)]


def rebuild_height_caches(heightmap: dict, heights: list[int]) -> None:
    """Rebuild native min/max quadtree and conservative LOD error bounds.

    The original stores levels leaf-first (32²,16²,...,1), with Z varying
    fastest.  A leaf contains 17×17 samples.  Parent height range bounds the
    error of every coarser triangulation, so it cannot select an unsafe LOD.
    """
    bounds, errors = [], []
    count = 32
    while count:
        width = (N - 1) // count
        for px in range(count):
            for pz in range(count):
                values = [heights[z * N + x]
                          for z in range(pz * width, (pz + 1) * width + 1)
                          for x in range(px * width, (px + 1) * width + 1)]
                lo, hi = min(values) / HEIGHT_DENOMINATOR, max(values) / HEIGHT_DENOMINATOR
                bounds.extend((lo, hi))
                errors.append(0.0 if count == 32 else hi - lo)
        count //= 2
    assert len(bounds) == len(heightmap["m_MinMaxPatchHeights"])
    assert len(errors) == len(heightmap["m_PrecomputedError"])
    heightmap["m_MinMaxPatchHeights"] = bounds
    heightmap["m_PrecomputedError"] = errors


def splat_weights(x: float, z: float) -> tuple[int, int, int, int]:
    delta = 1 / 512
    dx = (elevation(x + delta, z) - elevation(x - delta, z)) / (2 * delta * 100)
    dz = (elevation(x, z + delta) - elevation(x, z - delta)) / (2 * delta * 100)
    slope = math.sqrt(dx * dx + dz * dz)
    sand = 1 - smooth(.18, .29, z)
    beach_rock = smooth(.18, .25, z) * (1 - smooth(.28, .37, z))
    rock = max(beach_rock, smooth(.25, .95, slope))
    cliff = max(smooth(1.25, 2.5, slope), smooth(35, 44, elevation(x, z)))
    # Source order: GrassHill, GrassRocky, Cliff, Sand.
    values = [(1 - sand) * (1 - cliff) * (1 - rock),
              (1 - sand) * (1 - cliff) * rock,
              (1 - sand) * cliff, sand]
    integers = [int(v * 255) for v in values]
    integers[max(range(4), key=lambda i: values[i])] += 255 - sum(integers)
    return tuple(integers)


def make_alphamaps() -> tuple[bytes, int]:
    # RGBA32 bytes are stored bottom-to-top, matching terrain Z order.  Mips
    # average normalized splat weights rather than independent color channels.
    pixels = [splat_weights(x / 511, z / 511) for z in range(512) for x in range(512)]
    levels, width = [], 512
    while True:
        levels.append(bytes(channel for pixel in pixels for channel in pixel))
        if width == 1:
            break
        new_pixels = []
        for z in range(width // 2):
            for x in range(width // 2):
                group = [pixels[(2 * z + dz) * width + 2 * x + dx]
                         for dz in (0, 1) for dx in (0, 1)]
                sums = [sum(p[c] for p in group) for c in range(4)]
                average = [v // 4 for v in sums]
                average[max(range(4), key=lambda c: sums[c] % 4)] += 255 - sum(average)
                new_pixels.append(tuple(average))
        pixels, width = new_pixels, width // 2
    return b"".join(levels), len(levels)


def plant_meadow(database: dict, heights: list[int]) -> None:
    rng = random.Random(404)
    # Native instances reference the original Conifer_Desktop prototype 0.
    for i, tree in enumerate(database["m_TreeInstances"]):
        x = .12 + .76 * rng.random()
        z = .39 + .20 * rng.random()
        # Leave a clear arrival space in front of the first-person camera.
        if .41 < x < .59 and z < .49:
            x = .23 if i % 2 else .77
        tree["position"] = {"x": x, "y": heights[round(z * 512) * N + round(x * 512)] / HEIGHT_DENOMINATOR, "z": z}
        tree["index"] = 0
        tree["widthScale"] = tree["heightScale"] = .20 + .10 * rng.random()
    # Actual native grass detail patches; the same original alpha-textured
    # billboard prototype is used.  The symmetric patch square is well inside
    # the flat meadow in either documented array convention.
    patch_count, samples = database["m_PatchCount"], database["m_PatchSamples"]
    for index, patch in enumerate(database["m_Patches"]):
        px, pz = divmod(index, patch_count)
        active = .39 < (px + .5) / patch_count < .59 and .39 < (pz + .5) / patch_count < .59
        patch["layerIndices"] = [0] if active else []
        patch["numberOfObjects"] = ([1 if rng.random() < .18 else 0 for _ in range(samples * samples)] if active else [])
        # Publisher bounds are NaN sentinels.  Leave their supported sentinel
        # representation intact so Unity can calculate actual billboard bounds.


def guid(meta: Path) -> str:
    return re.search(r"^guid: (\w+)", meta.read_text(), re.M).group(1)


def serialized_guid(raw: bytes) -> str:
    # Unity serialized GUID bytes store the two nibbles in reverse order.
    return "".join(f"{value & 15:x}{value >> 4:x}" for value in raw)


def write_meta(source: Path, dest: Path, new_guid: str) -> None:
    dest.write_text(re.sub(r"^guid: \w+", "guid: " + new_guid, source.read_text(), flags=re.M))


def make_scene(source: Path, terrain_guid: str) -> str:
    text = (source / "Assets/Scenes/Adding Trees and Grass.unity").read_text()
    text = text.replace(guid(source / "Assets/Terrains/Trees and Grass.asset.meta"), terrain_guid)
    # Remove the original scene camera and its listener as the book instructs.
    blocks = re.split(r"(?=^--- !u!)", text, flags=re.M)
    blocks = [b for b in blocks if not re.match(r"--- !u!\d+ &(12446670[89]|12446671[012])\b", b)]
    text = "".join(blocks)
    fps = source / "Assets/Standard Assets/Characters/FirstPersonCharacter/Prefabs/FPSController.prefab"
    fps_guid = guid(fps.with_name(fps.name + ".meta"))
    # Unity 2018.1 uses this original (pre-2018.3) native prefab instance format.
    modifications = []
    for path, value in (("m_LocalPosition.x", 50), ("m_LocalPosition.y", 9.1),
                        ("m_LocalPosition.z", 40), ("m_RootOrder", 2),
                        ("m_LocalRotation.x", 0), ("m_LocalRotation.y", 0),
                        ("m_LocalRotation.z", 0), ("m_LocalRotation.w", 1)):
        modifications.append(f"    - target: {{fileID: 400000, guid: {fps_guid}, type: 2}}\n"
                             f"      propertyPath: {path}\n      value: {value}\n      objectReference: {{fileID: 0}}\n")
    text += ("--- !u!1001 &2000400000\nPrefab:\n  m_ObjectHideFlags: 0\n  serializedVersion: 2\n"
             "  m_Modification:\n    m_TransformParent: {fileID: 0}\n    m_Modifications:\n"
             + "".join(modifications) + "    m_RemovedComponents: []\n"
             f"  m_ParentPrefab: {{fileID: 100100000, guid: {fps_guid}, type: 2}}\n"
             "  m_IsPrefabParent: 0\n")
    return text


def build(source: Path, dest: Path) -> dict:
    original = source / "Assets/Terrains/Trees and Grass.asset"
    before = hashlib.sha256(original.read_bytes()).hexdigest()
    env = UnityPy.load(str(original))
    terrain = next(obj for obj in env.objects if obj.type.name == "TerrainData")
    texture = next(obj for obj in env.objects if obj.type.name == "Texture2D")
    data = terrain.read_typetree()
    original_splats = copy.deepcopy(data["m_SplatDatabase"]["m_Splats"])
    original_tree_prototypes = copy.deepcopy(data["m_DetailDatabase"]["m_TreePrototypes"])
    original_detail_prototypes = copy.deepcopy(data["m_DetailDatabase"]["m_DetailPrototypes"])
    data["m_Name"] = "Exercise Beach Mountains Plain"
    heights = make_heights()
    data["m_Heightmap"]["m_Heights"] = heights
    data["m_Heightmap"]["m_Scale"] = {"x": 100 / 512, "y": MAX_H, "z": 100 / 512}
    rebuild_height_caches(data["m_Heightmap"], heights)
    plant_meadow(data["m_DetailDatabase"], heights)
    terrain.save_typetree(data)
    tex = texture.read_typetree()
    rgba, mip_count = make_alphamaps()
    tex["m_TextureFormat"] = 4  # RGBA32, accepted by the original 2018.1 engine.
    tex["m_MipCount"] = mip_count
    tex["m_CompleteImageSize"] = len(rgba)
    tex["image data"] = rgba
    texture.save_typetree(tex)
    output = dest / TERRAIN_REL
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(env.file.save())
    write_meta(original.with_name(original.name + ".meta"), output.with_name(output.name + ".meta"), TERRAIN_GUID)
    scene = dest / SCENE_REL
    scene.parent.mkdir(parents=True, exist_ok=True)
    scene.write_text(make_scene(source, TERRAIN_GUID))
    write_meta(source / "Assets/Scenes/Adding Trees and Grass.unity.meta", scene.with_name(scene.name + ".meta"), SCENE_GUID)
    # Read the serialized output independently. Check actual native structures,
    # not the Python objects used to produce them.
    final = UnityPy.load(str(output))
    actual = next(obj for obj in final.objects if obj.type.name == "TerrainData").read_typetree()
    actual_tex = next(obj for obj in final.objects if obj.type.name == "Texture2D")
    at = actual_tex.read_typetree()
    assert actual["m_Heightmap"]["m_Heights"] == heights
    assert actual["m_SplatDatabase"]["m_Splats"] == original_splats
    assert actual["m_DetailDatabase"]["m_TreePrototypes"] == original_tree_prototypes
    assert actual["m_DetailDatabase"]["m_DetailPrototypes"] == original_detail_prototypes
    assert len(actual["m_DetailDatabase"]["m_TreeInstances"]) == 37
    assert len(at["image data"]) == 1398100
    base = at["image data"][:512 * 512 * 4]
    assert all(sum(at["image data"][i:i + 4]) == 255 for i in range(0, len(at["image data"]), 4))
    # Decoder validation verifies a real 512x512 texture with RGBA pixel data.
    image = actual_tex.read().image
    assert image.size == (512, 512) and image.mode == "RGBA"
    decoded = image.transpose(__import__("PIL.Image", fromlist=["Image"]).Transpose.FLIP_TOP_BOTTOM)
    assert decoded.tobytes() == base
    assert hashlib.sha256(original.read_bytes()).hexdigest() == before
    assert scene.read_text().count(f"guid: {TERRAIN_GUID}") == 2
    assert "Main Camera" not in scene.read_text()
    metadata = {guid(p): p.with_name(p.name[:-5]) for p in source.rglob("*.meta")}
    original_refs = [serialized_guid(external.guid) for external in terrain.assets_file.externals]
    assert all(reference in metadata and metadata[reference].is_file() for reference in original_refs)
    assert [serialized_guid(external.guid) for external in next(obj for obj in final.objects if obj.type.name == "TerrainData").assets_file.externals] == original_refs
    assert splat_weights(.5, .1)[3] == 255  # Sand beach.
    assert splat_weights(.5, .45)[0] == 255  # Flat GrassHill plain.
    assert max(base[2::4]) > 250  # Actual Cliff-painted mountaintops.
    assert all(heights[z * N + x] == heights[205 * N + 256]
               for z in range(205, 290) for x in (64, 256, 448))
    report = {
        "status": "PASS_STATIC_AND_SERIALIZATION_ROUNDTRIP", "unity_editor_run": False,
        "source_unchanged_sha256": before, "scene": SCENE_REL.as_posix(),
        "terrain": TERRAIN_REL.as_posix(), "terrain_size": [100, 60, 100],
        "heightmap_resolution": N, "height_range_world": [min(heights) / HEIGHT_DENOMINATOR * MAX_H, max(heights) / HEIGHT_DENOMINATOR * MAX_H],
        "flat_plain_world_y": 8, "splat_layers": ["GrassHillAlbedo", "GrassRockyAlbedo", "CliffAlbedoSpecular", "SandAlbedo"],
        "source_texture_and_prototype_refs_preserved": True, "alpha_resolution": 512,
        "all_external_asset_guids_resolve_in_original_project": True,
        "all_alpha_pixels_sum_255": True, "mipmap_levels": mip_count,
        "tree_instances": 37, "detail_patches_with_grass": sum(bool(p["layerIndices"]) for p in actual["m_DetailDatabase"]["m_Patches"]),
        "fps_prefab": "original Standard Assets FPSController", "fps_spawn": [50, 9.1, 40],
        "camera_audio_listener": "Original scene camera removed; FPS prefab has one enabled listener",
        "height_caches": "exact min/max quadtree; conservative parent LOD errors; native grass bounds sentinel preserved",
        "limitations": "Unity Editor 2018.1.0f1 import, rendering, movement and Windows build remain unrun in this environment."
    }
    (dest / "HOUR04-EXERCISE.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    (dest / "HOUR04-EXERCISE.md").write_text(
        "# Час 4: итоговое упражнение\n\n"
        "Откройте Assets/Scenes/Exercise Beach Mountains Plain.unity. Это сохранённая сцена с настоящим TerrainData, а не генератор при Play.\n\n"
        "Пляж SandAlbedo плавно переходит в GrassRockyAlbedo; равнина покрыта GrassHillAlbedo, склоны — GrassRockyAlbedo, вершины и крутые участки — CliffAlbedoSpecular. "
        "Все четыре текстуры, Conifer_Desktop и GrassFrond01AlbedoAlpha взяты из оригинального пакета книги; исходные GUID сохранены. Деревья и трава хранятся в native Terrain tree/detail layers.\n\n"
        "Terrain размером 100×60×100, карта высот 513×513. В сцене поставлен оригинальный FPSController: WASD, мышь, Space; Esc освобождает курсор. Его стартовая точка чуть выше равнины. Старая Main Camera удалена.\n\n"
        "Практикумы книги сохранены в исходных сценах Sculpting Terrain, Applying Heightmap, Texturing Terrain и Adding Trees and Grass; оригинальные TerrainData не изменялись.\n\n"
        "Проверено чтение записанного бинарного TerrainData, прототипы, 37 деревьев, настоящие detail patches и нормализованные alpha weights всех mipmaps. "
        "Unity Editor в этой среде не запускался; импорт, визуальный вид, управление и EXE требуют проверки в Unity 2018.1.0f1.\n")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--dest", type=Path, default=DEST)
    args = parser.parse_args()
    print(json.dumps(build(args.source, args.dest), indent=2, ensure_ascii=False))
