#!/usr/bin/env python3
"""Document chapter coverage, prepare a factual chapter24 review, and prune unused bulk."""
from pathlib import Path
import json,re,shutil,html,hashlib
import assemble_book_course as a
ROOT=Path(__file__).resolve().parents[1];COURSE=ROOT/'course'

def prune():
    removed=[]
    for h in [4,6,10]:
        p=COURSE/f'Hour{h:02d}'
        candidates=['Assets/Standard Assets/Characters/ThirdPersonCharacter','Assets/Standard Assets/Characters/RollerBall','Assets/Standard Assets/Environment/SpeedTree/Palm']
        if h==6:candidates+=['Assets/Standard Assets/Environment/SpeedTree/Broadleaf']
        if h==10:candidates+=['Assets/Standard Assets/Environment/SpeedTree']
        if h==4:candidates+=['Assets/Standard Assets/Environment/Water','Assets/Standard Assets/Environment/Water (Basic)']
        dirs=[p/s for s in candidates if (p/s).exists()]
        # Refuse pruning if any remaining text-serialized asset references one of
        # the candidate GUIDs. Binary terrain references have separate audits.
        removed_guids={}
        for folder in dirs:
            for meta in folder.rglob('*.meta'):
                m=re.search(r'^guid:\s*(\w+)',meta.read_text(errors='replace'),re.M)
                if m:removed_guids[m[1]]=meta
        references=[]
        for f in (p/'Assets').rglob('*'):
            if not f.is_file() or f.suffix.lower() not in ['.unity','.prefab','.mat','.asset','.controller','.anim','.playable']:continue
            if any(f==d or d in f.parents for d in dirs):continue
            data=f.read_bytes()
            if not data.startswith(b'%YAML'):continue
            for g in set(re.findall(rb'guid:\s*([a-f0-9]{32})',data)):
                if g.decode() in removed_guids:references.append([str(f.relative_to(p)),g.decode()])
        if references:raise RuntimeError('Pruning has retained references: '+str(references[:10]))
        for folder in dirs:
            if not folder.exists():continue
            removed.append({'hour':h,'path':folder.relative_to(p).as_posix(),'reason':'unused source assets, not required for this chapter; full publisher archive preserved in input release'})
            shutil.rmtree(folder)
            Path(str(folder)+'.meta').unlink(missing_ok=True)
        (p/'UNUSED_ASSETS_REMOVED.json').write_text(json.dumps([r for r in removed if r['hour']==h],ensure_ascii=False,indent=2)+'\n')
    return removed

def article24():
    p=COURSE/'Hour24'
    # Use exactly the improved chapter20 game as the subject of the written review.
    shutil.copy2(COURSE/'Hour20/Assets/Scripts/GameManager.cs',p/'Assets/Scripts/GameManager.cs')
    text='''# Час 24. Разбор учебной игры «Бег с препятствиями»

## Замысел и правила

«Бег с препятствиями» — учебная игра по книге Майка Гейга. Здесь разобрана реализация из сопроводительных материалов и внесённые дополнения; авторские ассеты и базовые механики не выдаются за самостоятельную разработку с нуля.

Игрок управляет персонажем, который остаётся примерно на одном месте, а движение мира создаётся прокруткой текстуры пола и приближающимися объектами. Горизонтальная ось ввода позволяет уклоняться в пределах трёх единиц от центра. Начальное время — 10 секунд; бонус добавляет 1,5 секунды, препятствие отнимает 0,5 секунды. При столкновении мир временно замедляется. Пробел включает фазовый проход: на время отключается коллайдер персонажа и применяется материал PhasedOut, затем восстанавливается Hologram.

## Устройство проекта

TextureScroller изменяет mainTextureOffset материала на каждом кадре с учётом deltaTime. Это сохраняет геометрию коридора неподвижной и создаёт иллюзию движения. Важно сохранять реальные UV модели, изображение текстуры и её режим повторения: изменение цвета однотонного материала этого эффекта не даёт.

Spawner чередует бонус и препятствие через заданный интервал, выбирает случайную координату X и передаёт созданному Collidable ссылку на GameManager. Collidable движется к игроку, изменяет время по контакту и уничтожается. TriggerZone удаляет объекты, прошедшие за камерой. Player ограничивает движение, меняет материал и состояние Collider во время фазового прохода. Анимация использует настоящий FBX персонажа и подготовленный клип бега.

## Что добавлено

В GameManager добавлен показ виртуальной дистанции. Она накапливается со скоростью 20 единиц за игровую секунду, соответствующей исходной скорости приближения препятствий. Это показатель движения в игровом мире, а не физическое перемещение корневого Transform персонажа. Клавиша R перезапускает сцену; перед загрузкой восстанавливается Time.timeScale, поэтому новая попытка не наследует остановленное время после поражения.

## Сильные стороны и ограничения

Небольшие отдельные скрипты позволяют независимо изучать ввод, спавн, триггеры, материалы и управление временем. Поля GameManager и Player связываются через Inspector, а исходные .meta сохраняют ссылки на материалы, модели и анимации.

При этом Instantiate/Destroy выполняются часто: для большего числа объектов стоит рассмотреть пул. Старый OnGUI подходит учебному прототипу, но интерфейс можно перенести на Canvas. Код замедления использует Invoke и масштабируемое игровое время: при оценке длительности эффекта надо различать игровые и реальные секунды. Переменная виртуальной скорости должна оставаться согласованной со скоростью приближения объектов.

## Что действительно проверено

Проверены исходные файлы и назначенные ассеты: наличие текстур, материалов, моделей, анимации, структура сцен и синтаксис C#. Исходные данные взяты из предоставленного архива книги. Импорт в Unity2018.1.0f1, Play, реальные ощущения от управления, баланс сложности, производительность и Windows EXE в облачной среде не проверены. Отзывы игроков не выдумывались.

## Дальнейшая проверка

На целевом редакторе нужно проверить движение и границы, получение бонуса, штраф, замедление, фазовый проход и восстановление Collider, поражение и повторный запуск. Затем собрать Windows-версию и проверить её отдельно от редактора. Для оценки удобства и баланса нужны реальные участники: наблюдения следует записать и использовать для следующего изменения.

Это технический разбор по реально подготовленным исходникам. Перед окончательной сдачей добавьте собственные наблюдения после запуска и сведения о выполненных практических проверках.
'''
    (p/'Разбор игры.md').write_text(text)
    paragraphs=[]
    for line in text.splitlines():
        if line.startswith('# '):paragraphs.append('<h1>'+html.escape(line[2:])+'</h1>')
        elif line.startswith('## '):paragraphs.append('<h2>'+html.escape(line[3:])+'</h2>')
        elif line.strip():paragraphs.append('<p>'+html.escape(line)+'</p>')
    (p/'Разбор игры.html').write_text('<!doctype html><html lang="ru"><meta charset="utf-8"><title>Час24 — разбор игры</title><style>body{max-width:850px;margin:36px auto;font:17px/1.6 Georgia,serif;padding:0 22px}h1,h2{font-family:Arial,sans-serif}@media print{body{margin:0;font-size:12pt}}</style>'+''.join(paragraphs)+'</html>')

def main():
    removed=prune();article24();records=json.loads((COURSE/'manifest.json').read_text())
    for record in records:
        h=record['hour'];p=COURSE/f'Hour{h:02d}'
        primary=a.configure(h,p)
        record['primary_scene']=primary
        if h in [17,19]:record.update(primary_scene='Assets/Scenes/Exercise.unity',requires_editor_preparation=True,preparation_status='UNRUN: first Editor import saves native exercise scene/assets')
        if h==4:record['binary_terrain_roundtrip']='PASS; heights/splat weights/real vegetation checked, Unity import UNRUN'
        if h==24:record['written_report']='Разбор игры.html'
        record['project_primary_path']=f'Hour{h:02d}'
        (p/'chapter.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
        readme=(p/'ОТКРЫТЬ.md').read_text()
        if h in [17,19]:readme+='\nУпражнение Exercise.unity создаётся и сохраняется однократно редакторным дополнением при первом импорте. Эта подготовка здесь ещё не исполнялась. Если автоматически не создалось, Book → Hour '+str(h)+'/Create missing exercise assets. После подготовки сцена открывается и добавляется первой в Build Settings. Оригинальные сцены главы уже сохранены в Assets/Scenes.\n'
        if h==4:readme+='\nИтоговая сцена: Assets/Scenes/Exercise Beach Mountains Plain.unity — настоящий TerrainData с пляжем, горным хребтом, равниной, текстурными переходами, деревьями, травой и оригинальным FPSController. Бинарные данные записаны и повторно прочитаны; визуальный запуск не проверен.\n'
        if h in [6,10,20]:readme+='\nТворческое дополнение главы описано в EXERCISE.md или README.md. Основные текстуры и механики автора сохранены.\n'
        if h==15:
            (p/'Плейтест.md').write_text('''# Час15 — реальные отзывы

Упражнение требует дать игру людям с разным игровым опытом. Плейтест ещё не проведён; выдуманных отзывов здесь нет.

| Участник | Опыт | Что было понятно/непонятно | Проблема | Предложение |
|---|---|---|---|---|
| Заполнить после игры | | | | |

Изменение по отзывам и результат повторной проверки: заполнить после реальной работы.
''')
            readme+='\nИтоговое упражнение15 включает реальные отзывы игроков; см.Плейтест.md. Они ещё не получены.\n'
        if h==18:readme+='\nИтоговое исследование: сравните собственный Animator персонажа с Assets/Standard Assets/Characters/ThirdPersonCharacter/Prefabs/ThirdPersonController.prefab, его Grounded/Airborne/Crouching и параметрами. Основной авторский контроллер Speed/Direction сохранён. Импорт Humanoid и движения в Play требуют проверки.\n'
        if h==22:readme+='\nНастоящие проверки Unity Remote/акселерометра/трёх пальцев требуют телефона и USB. Это ещё не проверено; мышь не считается заменой устройства.\n'
        if h==24:readme+='\nОсновная работа часа24 — Разбор игры.html (открывается в браузере и печатается) и Markdown. Игровая сцена приложена для анализа. Дополните разбор собственными наблюдениями после проверки.\n'
        if not (p/'Practice').exists():readme=readme.replace('Папка Practice (если есть) — отдельный проект с оригинальными практикумами издательства. Открывать через File → Open Project → Practice. Сцены находятся в её Assets/Scenes. Это не набор скриптов для копирования в основной Assets.','Все основные практикумы данного авторского проекта уже находятся в Assets/Scenes этой папки.')
        if h==7 and (p/'DETAILS.md').exists():
            detail=(p/'DETAILS.md').read_text()
            detail=detail.replace('Ссылка на оригинальный EqualityAndOperations.cs есть на стр.160, но сам файл относится к отдельному архиву примеров. Он здесь не объявлен полученным или проверенным.', 'Оригинальный EqualityAndOperations.cs из архива издательства теперь сохранён в Assets/PublisherExamples и отдельной сцене03b.')
            (p/'DETAILS.md').write_text(detail)
        if h==9 and (p/'DETAILS.md').exists():
            detail=(p/'DETAILS.md').read_text().replace('Стандартные оригиналы не получены из заблокированного архива и не выдаются за приложенные.', 'Оригинальные материалы из предоставленного архива сохранены отдельно в Assets/OriginalPhysicsMaterials; сцены03c/03d используют их. Ниже описаны дополнительные собственные эксперименты03a/03b.')
            detail=detail.replace('Для точного выполнения шага Import Package → Characters → Physics Materials нужен оригинальный пакет; этот шаг остаётся внешним ограничением.', 'Исходные PhysicsMaterials уже скопированы из Standard Assets предоставленного архива; их можно изучить в Inspector и оригинальных сценах03c/03d.')
            (p/'DETAILS.md').write_text(detail)
        if (p/'scene_manifest.json').exists():
            old=json.loads((p/'scene_manifest.json').read_text())
            old['companion_assets_obtained']=True
            if h==9:old['original_package_import']='Original Standard Assets PhysicsMaterials included; see scenes03c/03d.'
            old['scenes']=[{'path':f.relative_to(p).as_posix(),'guid':re.search(r'^guid: (\w+)',Path(str(f)+'.meta').read_text(),re.M)[1]} for f in sorted((p/'Assets/Scenes').glob('*.unity'))]
            (p/'scene_manifest.json').write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n')
        (p/'ОТКРЫТЬ.md').write_text(readme)
    (COURSE/'manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
    rows='\n'.join(f"|{r['hour']:02d}|{r['title']}|[Открытие](Hour{r['hour']:02d}/ОТКРЫТЬ.md)|" for r in records)
    (COURSE/'README.md').write_text('''# Комплекты по 24 часам книги — Unity2018.1.0f1

В каждом HourNN корень — отдельный проект: Assets и ProjectSettings. Unity Hub не требуется. File → Open Project → HourNN. Внутри есть инструкция с конкретной сценой. Practice и PublisherExercise, если присутствуют, — самостоятельные дополнительные проекты; не копируйте их Assets в основной проект.

Использован оригинальный Unity.zip из вашего релиза book-files, SHA256e81725573d2570ba1ba36d7d2f6acd9ac4176c8799c766ba5696c6bb15291192. Оригинальные текстуры, normal maps, UV-модели, риги и клипы сохранены. Исходники редактора beta перенесены в рабочие копии с версией2018.1.0f1. Кэш Library исключён. Неиспользуемые тяжёлые StandardAssets удалены только из глав4/6/10; список в каждом проекте, полный исходный архив остаётся в вашем релизе.

Это не24проверенныхEXE. Файловые проверки не заменяют Unity: импорт, компиляция с API, Play, звук, физика и Windows-сборки здесь ещё не выполнялись. Часы17/19 дополнительно сохраняют недостающие упражнения редакторным скриптом при первом импорте; эта подготовка здесь не запускалась. Час15 требует реального плейтеста,22—устройства,23—сборки и запуска,24—собственных наблюдений в отчёте.

Для сборки: Book → Build Windows x64; нужен Windows Build Support версии2018.1.0f1. Готовый запуск состоит из EXE, *_Data и DLL вместе. В архивах сейчас исходники, не EXE.

|Час|Тема|Инструкция|
|---|---|---|
'''+rows+'\n')
    print('Finalized 24 source packages; unused bulk removed:',len(removed),'folders. Engine checks UNRUN.')
if __name__=='__main__':main()
