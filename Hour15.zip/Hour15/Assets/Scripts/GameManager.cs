using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI; // Note this new line is needed for UI

public class GameManager : MonoBehaviour
{
	public Text scoreText;
	public Text gameOverText;

	int playerScore = 0;
    void Awake() { Time.timeScale = 1f; }
    void Update() { if (Input.GetKeyDown(KeyCode.R)) { Time.timeScale = 1f; SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex); } }

	public void AddScore()
	{
		playerScore++;
		//This converts the score (a number) into a string
		scoreText.text = playerScore.ToString();
	}

	public void PlayerDied()
	{
		gameOverText.enabled = true;

		// This freezes the game
		Time.timeScale = 0;				
	}
}
