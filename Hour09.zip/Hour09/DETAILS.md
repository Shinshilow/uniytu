# Час 9 — столкновения, физика, триггеры и рейкастинг

Unity **2018.1.0f1**, как на вашем скриншоте. Откройте папку Hour09 через File → Open Project. Сцены уже сохранены в Assets/Scenes: видимые объекты, Rigidbody, коллайдеры и привязки скриптов существуют до Play. Нет CourseSetup, общего Lesson.cs, UI-накладок или создания геометрии при запуске.

Начните с **06_Exercise_TwoTriggers.unity**: стрелки или WASD перемещают Sphere по мировым X/Z. В Console видны LTrigger/RTrigger и тип события: вход, нахождение внутри, выход. Для каждого повтора остановите Play и запустите снова: сцена вернётся к сохранённым координатам.

## Соответствие книге

| Блок книги | Сцена | Сохранённый результат и проверка |
|---|---|---|
| 09-P01, стр.191, до Rigidbody | 01a_Rigidbody_Baseline | Cube (0,1,-5), Rigidbody отсутствует; при Play не должен падать. |
| 09-P01, стр.191, после Rigidbody | 01b_Rigidbody_Gravity | Тот же Cube с Rigidbody, Use Gravity включён; должен падать. Плоскость не добавлена, как в практикуме. |
| 09-P01, эксперимент с Drag | 01c_Rigidbody_DragStudy | Тот же объект, Drag=5 — собственное выбранное значение для сравнения скорости падения. |
| 09-P01, эксперимент с Constraints | 01d_Rigidbody_FreezeYStudy | Freeze Position Y, Use Gravity включён; сравните с 01b. Выбор оси — исследовательский вариант, не фиксированная константа книги. |
| 09-P02, стр.193, пункт3 | 02a_Colliders_Unrestrained | Верхний Cube (0,1,-5) с гравитацией; нижний (0,-1,-5), Scale(4,.1,4), Z15°, Rigidbody без гравитации и без ограничений. |
| 09-P02, стр.194, пункты4–5 | 02b_Colliders_FreezeAll | У нижнего Rigidbody заморожены все позиции и вращения; оба куба с BoxCollider. |
| 09-P02, стр.194, пункты6–7 | 02c_CubeWithSphereCollider | Видимый верхний куб теперь имеет SphereCollider вместо BoxCollider; нижний Z350° и FreezeAll. Проверить скатывание. |
| 09-P02, стр.194, пункт8 | 02d_LowerCube_FreezeYStudy | У нижнего заморожен только PositionY; остальные степени свободы оставлены свободными. |
| 09-A01, стр.194–196 | 03a_AuthoredPhysicMaterials_Friction / 03b_AuthoredPhysicMaterials_Bounce | Пять настоящих .physicMaterial-ассетов назначены Collider.sharedMaterial, не MeshRenderer. Это собственные опыты по свойствам Dynamic/Static Friction, Bounciness и Combine. Не оригинальные Bouncy/Ice/Metal/Rubber/Tree из Standard Assets. |
| 09-P03, стр.197 | 04_MouseTrigger | Cube(-1,1,-5) с IsTrigger=true и TriggerScript; Sphere(1,1,-5) с Rigidbody без гравитации и MovementScript. Мышь сдвигает сферу на MouseX/10,MouseY/10; три сообщения книги печатаются в Console. |
| 09-P04, стр.199–200 | 05_Raycast | Четыре сферы в(-1,1,-5),(1,1.5,-5),(-1,-2,5),(1.5,0,0). RaycastScript на Main Camera поворачивает её от мыши; каждый кадр проверяет луч и уничтожает объект попадания. Кнопка стрельбы не добавлена. |
| 09-E01, стр.201–202 | 06_Exercise_TwoTriggers | LTrigger(-1.5,0,-5), RTrigger(1.5,0,-5), Scale(.1,2,2), оба IsTrigger=true. Sphere(0,0,-5), Rigidbody без гравитации, MotionScript. Rigidbody.MovePosition вызывается в FixedUpdate. |

В сценах MouseTrigger и итогового упражнения OnTriggerStay печатается на каждом физическом шаге, как в книжном примере. Для чтения можно включить Collapse в Console; при необходимости увидеть отдельные события выключите его. Это не сообщение об ошибке.

## Собственные физические материалы

В книге прямо разрешено создавать свои материалы, однако готовый пакет также упоминается. Оригинальные материалы из предоставленного архива сохранены отдельно в Assets/OriginalPhysicsMaterials; сцены03c/03d используют их. Ниже описаны собственные эксперименты03a/03b. Для изучения сохранены следующие явно выбранные значения:

| Файл Authored_* | Dynamic Friction | Static Friction | Bounciness | Friction Combine | Bounce Combine |
|---|---:|---:|---:|---|---|
| BouncyStudy |0|0|1|Average|Maximum|
| IceStudy |0|0|0|Average|Average|
| MetalStudy |.2|.3|.05|Average|Average|
| RubberStudy |.9|1|.7|Maximum|Maximum|
| TreeStudy |.5|.6|.1|Average|Average|

Откройте материалы в Inspector и изменяйте параметры, затем сравнивайте поведение в Play. Значения названий здесь учебные, не измеренные физические характеристики реальных веществ. Оригинальные PhysicsMaterials уже получены; их можно изучить в Inspector и сценах03c/03d.

Глава посвящена физическим материалам, а не текстурным картам. Использован стандартный рендер-материал Unity; PhysicMaterial назначен именно коллайдерам. Пустые текстуры не выдаются за выполненный UV/normal mapping другой главы.

**Проверки:** сохранённые YAML-сцены, локальные fileID, ссылки на скрипты/физические материалы, точные координаты и флаги проверены статически. Синтаксис C# проверен парсером. Импорт, компиляция Unity API, физическое поведение в Play и EXE-сборка здесь НЕ выполнялись. Готовность к сдаче без этих проверок не утверждается.

Оригинальные PhysicsMaterials из предоставленного архива добавлены в Assets/OriginalPhysicsMaterials. Сцены03c/03d используют настоящие Bouncy,Ice,Metal,Rubber,Wood из Standard Assets. Сцены03a/03b оставлены как отдельные собственные эксперименты, их не следует путать с оригиналами.
