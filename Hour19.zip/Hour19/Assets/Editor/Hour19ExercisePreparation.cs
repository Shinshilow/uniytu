using System.IO;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.SceneManagement;
using UnityEngine.Timeline;
using UnityEngine.UI;

// Editor-only preparation: saves a real TimelineAsset, native clips and scene.
[InitializeOnLoad]
public static class Hour19ExercisePreparation
{
    const string Folder = "Assets/BookExercise19";
    const string ScenePath = "Assets/Scenes/Exercise.unity";
    const string Marker = Folder + "/Prepared.txt";
    static bool preparing;
    static Hour19ExercisePreparation() { EditorApplication.delayCall += PrepareIfMissing; }

    [MenuItem("Book/Hour 19/Create missing exercise assets")]
    public static void PrepareIfMissing()
    {
        if (preparing || File.Exists(Marker)) return;
        if (EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode)
        { EditorApplication.delayCall += PrepareIfMissing; return; }
        if (File.Exists(ScenePath)) return;
        preparing = true;
        Scene previous = SceneManager.GetActiveScene();
        Scene scene = default(Scene);
        bool completed = false;
        try
        {
            Directory.CreateDirectory(Folder);
            Directory.CreateDirectory("Assets/Scenes");
            AssetDatabase.Refresh();
            scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            SceneManager.SetActiveScene(scene);
            GameObject directorObject = new GameObject("Exercise Timeline Director");
            PlayableDirector director = directorObject.AddComponent<PlayableDirector>();
            director.playOnAwake = false;
            director.extrapolationMode = DirectorWrapMode.Loop;
            directorObject.AddComponent<InputControl>(); // Original book Space Play/Stop script.
            TimelineAsset timeline = ScriptableObject.CreateInstance<TimelineAsset>();
            timeline.name = "Patrol Camera UI and Light";
            AssetDatabase.CreateAsset(timeline, Folder + "/ExerciseTimeline.playable");
            director.playableAsset = timeline;

            GameObject cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            Camera camera = cameraObject.AddComponent<Camera>();
            camera.backgroundColor = new Color(.06f, .08f, .12f);
            cameraObject.AddComponent<AudioListener>();
            cameraObject.transform.position = new Vector3(0, 4, -12);
            cameraObject.transform.rotation = Quaternion.Euler(18, 0, 0);
            Animator cameraAnimator = cameraObject.AddComponent<Animator>();
            cameraAnimator.applyRootMotion = false;
            AnimationTrack cameraTrack = timeline.CreateTrack<AnimationTrack>(null, "Camera: two saved shots");
            director.SetGenericBinding(cameraTrack, cameraAnimator);
            AnimationClip shot1 = Clip("CameraShot1");
            Set(shot1, typeof(Transform), "m_LocalPosition.x", AnimationCurve.Linear(0, -1.5f, 4, 1.5f));
            Set(shot1, typeof(Transform), "m_LocalPosition.y", AnimationCurve.Constant(0, 4, 4));
            Set(shot1, typeof(Transform), "m_LocalPosition.z", AnimationCurve.Linear(0, -12, 4, -10));
            AddAnimation(cameraTrack, shot1, 0, 4);
            AnimationClip shot2 = Clip("CameraShot2");
            Set(shot2, typeof(Transform), "m_LocalPosition.x", AnimationCurve.Linear(0, 1.5f, 4, -1.5f));
            Set(shot2, typeof(Transform), "m_LocalPosition.y", AnimationCurve.Constant(0, 4, 4));
            Set(shot2, typeof(Transform), "m_LocalPosition.z", AnimationCurve.Linear(0, -10, 4, -12));
            AddAnimation(cameraTrack, shot2, 4, 4);

            GameObject daylightObject = new GameObject("Directional Light");
            Light daylight = daylightObject.AddComponent<Light>();
            daylight.type = LightType.Directional;
            daylight.intensity = .8f;
            daylightObject.transform.rotation = Quaternion.Euler(45, -30, 0);
            GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
            floor.name = "Patrol floor";
            floor.GetComponent<Renderer>().sharedMaterial = Material("Floor", new Color(.2f, .24f, .3f));
            GameObject guard = GameObject.CreatePrimitive(PrimitiveType.Cube);
            guard.name = "Guard patrol (animated object)";
            guard.transform.position = new Vector3(-3, .5f, 0);
            guard.GetComponent<Renderer>().sharedMaterial = Material("Guard", new Color(.15f, .65f, .95f));
            Animator guardAnimator = guard.AddComponent<Animator>();
            guardAnimator.applyRootMotion = false;
            AnimationClip patrol = Clip("GuardPatrol");
            Set(patrol, typeof(Transform), "m_LocalPosition.x", new AnimationCurve(new Keyframe(0, -3), new Keyframe(4, 3), new Keyframe(8, -3)));
            Set(patrol, typeof(Transform), "m_LocalPosition.y", AnimationCurve.Constant(0, 8, .5f));
            Set(patrol, typeof(Transform), "m_LocalPosition.z", AnimationCurve.Constant(0, 8, 0));
            AnimationTrack patrolTrack = timeline.CreateTrack<AnimationTrack>(null, "Guard patrol");
            director.SetGenericBinding(patrolTrack, guardAnimator);
            AddAnimation(patrolTrack, patrol, 0, 8);

            GameObject lamp = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            lamp.name = "Activation-track strobe";
            lamp.transform.position = new Vector3(0, 2.5f, 1);
            lamp.transform.localScale = Vector3.one * .4f;
            lamp.GetComponent<Renderer>().sharedMaterial = Material("Lamp", Color.yellow);
            Light bulb = lamp.AddComponent<Light>();
            bulb.type = LightType.Point;
            bulb.color = Color.yellow;
            bulb.range = 8;
            bulb.intensity = 3;
            ActivationTrack activationTrack = timeline.CreateTrack<ActivationTrack>(null, "Light strobe (activation)");
            director.SetGenericBinding(activationTrack, lamp);
            lamp.SetActive(false);
            for (int i = 0; i < 8; i++)
            {
                TimelineClip on = activationTrack.CreateDefaultClip();
                on.displayName = "Light ON";
                on.start = i + .5;
                on.duration = .2;
            }

            GameObject canvasObject = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasObject.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
            CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1280, 720);
            Text instructions = Text(canvasObject.transform, "Instructions", "SPACE: play / stop Timeline. Inspect the four native tracks in Timeline.", new Vector2(0, -300), 25);
            instructions.rectTransform.sizeDelta = new Vector2(1200, 70);
            Text title = Text(canvasObject.transform, "Animated UI", "HOUR 19: TIMELINE EXPERIMENTS", new Vector2(-200, 280), 32);
            title.rectTransform.sizeDelta = new Vector2(1100, 65);
            Animator titleAnimator = title.gameObject.AddComponent<Animator>();
            AnimationClip uiClip = Clip("AnimatedUI");
            Set(uiClip, typeof(RectTransform), "m_AnchoredPosition.x", new AnimationCurve(new Keyframe(0, -200), new Keyframe(4, 200), new Keyframe(8, -200)));
            Set(uiClip, typeof(RectTransform), "m_AnchoredPosition.y", AnimationCurve.Constant(0, 8, 280));
            Set(uiClip, typeof(Text), "m_Color.a", new AnimationCurve(new Keyframe(0, .4f), new Keyframe(2, 1), new Keyframe(4, .4f), new Keyframe(6, 1), new Keyframe(8, .4f)));
            AnimationTrack uiTrack = timeline.CreateTrack<AnimationTrack>(null, "Dynamic UI");
            director.SetGenericBinding(uiTrack, titleAnimator);
            AddAnimation(uiTrack, uiClip, 0, 8);

            AudioClip beep = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Audio/Beep High.wav");
            if (beep != null)
            {
                AudioSource audio = directorObject.AddComponent<AudioSource>();
                audio.playOnAwake = false;
                audio.spatialBlend = 0;
                AudioTrack audioTrack = timeline.CreateTrack<AudioTrack>(null, "Original beep aligned to light");
                director.SetGenericBinding(audioTrack, audio);
                for (int i = 0; i < 8; i++)
                {
                    TimelineClip clip = audioTrack.CreateDefaultClip();
                    ((AudioPlayableAsset)clip.asset).clip = beep;
                    clip.start = i + .5;
                    clip.duration = System.Math.Min(.2, beep.length);
                    clip.displayName = "Beep High";
                }
            }
            EditorUtility.SetDirty(timeline);
            PrepareOriginalAudioBindings();
            PrepareUnblendedStage();
            SceneManager.SetActiveScene(scene);
            EditorSceneManager.MarkSceneDirty(scene);
            if (!EditorSceneManager.SaveScene(scene, ScenePath))
                throw new System.IO.IOException("Could not save final exercise scene.");
            AssetDatabase.SaveAssets();
            AddBuildSceneFirst();
            File.WriteAllText(Marker, "Saved native Timeline extension with camera, patrol, UI, activation and original beep.\n");
            AssetDatabase.ImportAsset(Marker);
            completed = true;
        }
        finally
        {
            if (completed && scene.IsValid())
            {
                bool otherSceneDirty = false;
                for (int i = 0; i < SceneManager.sceneCount; i++)
                {
                    Scene openScene = SceneManager.GetSceneAt(i);
                    if (openScene.handle != scene.handle && openScene.isDirty) otherSceneDirty = true;
                }
                if (otherSceneDirty) SceneManager.SetActiveScene(scene);
                else EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
            }
            else
            {
                if (scene.IsValid()) EditorSceneManager.CloseScene(scene, true);
                if (previous.IsValid() && previous.isLoaded) SceneManager.SetActiveScene(previous);
            }
            preparing = false;
        }
    }

    static void PrepareOriginalAudioBindings()
    {
        string[] paths = { "Assets/Scenes/Adding tracks.unity", "Assets/Scenes/Scripting.unity" };
        foreach (string path in paths)
        {
            if (!File.Exists(path)) continue;
            Scene original = SceneManager.GetSceneByPath(path);
            bool alreadyOpen = original.IsValid() && original.isLoaded;
            if (alreadyOpen && original.isDirty)
                throw new System.InvalidOperationException("Save the open scene before preparing its Timeline audio: " + path);
            if (!alreadyOpen) original = EditorSceneManager.OpenScene(path, OpenSceneMode.Additive);
            try
            {
                bool changed = false;
                foreach (GameObject root in original.GetRootGameObjects())
                foreach (PlayableDirector director in root.GetComponentsInChildren<PlayableDirector>(true))
                {
                    TimelineAsset timeline = director.playableAsset as TimelineAsset;
                    if (timeline == null) continue;
                    foreach (TrackAsset track in timeline.GetOutputTracks())
                    {
                        if (!(track is AudioTrack) || director.GetGenericBinding(track) != null) continue;
                        AudioSource source = director.GetComponent<AudioSource>();
                        if (source == null) source = director.gameObject.AddComponent<AudioSource>();
                        source.playOnAwake = false;
                        source.spatialBlend = 0;
                        director.SetGenericBinding(track, source);
                        changed = true;
                    }
                }
                if (changed)
                {
                    EditorSceneManager.MarkSceneDirty(original);
                    if (!EditorSceneManager.SaveScene(original, path))
                        throw new System.IO.IOException("Could not save Timeline audio bindings: " + path);
                }
            }
            finally { if (!alreadyOpen) EditorSceneManager.CloseScene(original, true); }
        }
    }

    static void PrepareUnblendedStage()
    {
        const string path = "Assets/Scenes/Unblended.unity";
        if (File.Exists(path)) return;
        Scene previous = SceneManager.GetActiveScene();
        Scene stage = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
        SceneManager.SetActiveScene(stage);
        try
        {
            TimelineAsset timeline = ScriptableObject.CreateInstance<TimelineAsset>();
            timeline.name = "Seven colors before blending";
            AssetDatabase.CreateAsset(timeline, Folder + "/UnblendedTimeline.playable");
            GameObject directorObject = new GameObject("Unblended Timeline Director");
            PlayableDirector director = directorObject.AddComponent<PlayableDirector>();
            director.playableAsset = timeline;
            director.playOnAwake = true;
            director.extrapolationMode = DirectorWrapMode.Loop;
            AudioSource audio = directorObject.AddComponent<AudioSource>();
            audio.playOnAwake = false;
            audio.spatialBlend = 0;
            GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cube.name = "Rainbow Cube";
            cube.GetComponent<Renderer>().sharedMaterial = Material("UnblendedCube", Color.red);
            Animator animator = cube.AddComponent<Animator>();
            animator.applyRootMotion = false;
            AnimationTrack colors = timeline.CreateTrack<AnimationTrack>(null, "Seven colors, no overlap");
            AudioTrack beeps = timeline.CreateTrack<AudioTrack>(null, "Beep at each color start");
            director.SetGenericBinding(colors, animator);
            director.SetGenericBinding(beeps, audio);
            AudioClip beep = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Audio/Beep High.wav");
            string[] names = { "Red", "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet" };
            for (int i = 0; i < names.Length; i++)
            {
                AnimationClip animation = AssetDatabase.LoadAssetAtPath<AnimationClip>("Assets/Animations/" + names[i] + ".anim");
                if (animation == null) throw new System.IO.FileNotFoundException("Original color clip missing: " + names[i]);
                AddAnimation(colors, animation, i, 1);
                if (beep != null)
                {
                    TimelineClip clip = beeps.CreateDefaultClip();
                    ((AudioPlayableAsset)clip.asset).clip = beep;
                    clip.start = i;
                    clip.duration = System.Math.Min(.5, beep.length);
                    clip.displayName = "Beep High";
                }
            }
            GameObject cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            cameraObject.AddComponent<Camera>().backgroundColor = new Color(.1f, .12f, .16f);
            cameraObject.AddComponent<AudioListener>();
            cameraObject.transform.position = new Vector3(0, 1, -6);
            cameraObject.transform.LookAt(Vector3.zero);
            GameObject lightObject = new GameObject("Directional Light");
            Light light = lightObject.AddComponent<Light>();
            light.type = LightType.Directional;
            lightObject.transform.rotation = Quaternion.Euler(40, -30, 0);
            EditorUtility.SetDirty(timeline);
            EditorSceneManager.MarkSceneDirty(stage);
            if (!EditorSceneManager.SaveScene(stage, path))
                throw new System.IO.IOException("Could not save unblended Timeline scene.");
            AssetDatabase.SaveAssets();
            List<EditorBuildSettingsScene> scenes = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
            bool found = false;
            foreach (EditorBuildSettingsScene scene in scenes) if (scene.path == path) found = true;
            if (!found) scenes.Add(new EditorBuildSettingsScene(path, true));
            EditorBuildSettings.scenes = scenes.ToArray();
        }
        finally
        {
            if (stage.IsValid()) EditorSceneManager.CloseScene(stage, true);
            if (previous.IsValid() && previous.isLoaded) SceneManager.SetActiveScene(previous);
        }
    }

    static void AddBuildSceneFirst()
    {
        List<EditorBuildSettingsScene> scenes = new List<EditorBuildSettingsScene>();
        scenes.Add(new EditorBuildSettingsScene(ScenePath, true));
        foreach (EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
            if (scene.path != ScenePath) scenes.Add(scene);
        EditorBuildSettings.scenes = scenes.ToArray();
    }

    static Material Material(string name, Color color)
    {
        Material material = new Material(Shader.Find("Standard"));
        material.name = name;
        material.color = color;
        AssetDatabase.CreateAsset(material, Folder + "/" + name + ".mat");
        return material;
    }
    static AnimationClip Clip(string name)
    {
        AnimationClip clip = new AnimationClip();
        clip.name = name;
        clip.frameRate = 60;
        AssetDatabase.CreateAsset(clip, Folder + "/" + name + ".anim");
        return clip;
    }
    static void Set(AnimationClip clip, System.Type type, string property, AnimationCurve curve)
    { AnimationUtility.SetEditorCurve(clip, EditorCurveBinding.FloatCurve("", type, property), curve); }
    static void AddAnimation(AnimationTrack track, AnimationClip animation, double start, double duration)
    {
        TimelineClip clip = track.CreateDefaultClip();
        ((AnimationPlayableAsset)clip.asset).clip = animation;
        clip.start = start;
        clip.duration = duration;
        clip.displayName = animation.name;
    }
    static Text Text(Transform parent, string name, string content, Vector2 position, int size)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
        go.transform.SetParent(parent, false);
        Text text = go.GetComponent<Text>();
        text.text = content;
        text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        text.fontSize = size;
        text.color = Color.white;
        text.alignment = TextAnchor.MiddleCenter;
        text.rectTransform.anchorMin = new Vector2(.5f, .5f);
        text.rectTransform.anchorMax = new Vector2(.5f, .5f);
        text.rectTransform.anchoredPosition = position;
        return text;
    }
}
