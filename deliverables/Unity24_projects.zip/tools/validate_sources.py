#!/usr/bin/env python3
"""Static artifact checks; deliberately does not claim Unity readiness."""
from pathlib import Path
import hashlib,json,re,zipfile
root=Path(__file__).resolve().parents[1]
course=root/'Unity24'
items=json.loads((course/'manifest.json').read_text())
assert [x['hour'] for x in items]==list(range(1,25))
shared=list((course/'SharedSource').rglob('*.cs'))
assert len(shared)>=10
for item in items:
    h=item['hour'];project=course/f'Hour{h:02d}'
    assert (project/'Assets/Resources/hour.txt').read_text().strip()==str(h)
    assert (project/'Задание_из_книги.txt').stat().st_size>150
    assert (project/'ОТКРЫТЬ.md').exists()
    scene=(project/'Assets/Scenes/Lesson.unity').read_text()
    assert f'  hour: {h}\n' in scene
    guid=re.search('guid: ([a-f0-9]{32})',scene).group(1)
    assert guid in (project/'Assets/Scripts/Lesson.cs.meta').read_text()
    for source in shared:
        group='Editor' if source.parent.name=='Editor' else 'Scripts'
        assert (project/'Assets'/group/source.name).read_bytes()==source.read_bytes()
    axes=(project/'ProjectSettings/InputManager.asset').read_text()
    for axis in ['Horizontal','Vertical','Mouse X','Mouse Y','Submit','Cancel','Jump']:
        assert f'm_Name: {axis}\n' in axes
    archive=root/'deliverables'/f'Hour{h:02d}.zip'
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert f'Hour{h:02d}/Assets/Scenes/Lesson.unity' in z.namelist()
        assert not any(name.endswith('.exe') for name in z.namelist())
        assert z.read(f'Hour{h:02d}/Assets/Scripts/Lesson.cs')==(project/'Assets/Scripts/Lesson.cs').read_bytes()
with zipfile.ZipFile(root/'deliverables/Unity24_исходные_проекты.zip') as z:
    assert z.testzip() is None
print('PASS: 24 project structures; matching source copies and scene GUIDs; 25 ZIPs intact.')
try:
    from tree_sitter import Language,Parser
    import tree_sitter_c_sharp
except ImportError:
    print('UNRUN: C# syntax parsing (optional tree-sitter packages absent).')
else:
    parser=Parser(Language(tree_sitter_c_sharp.language()))
    for source in shared:
        tree=parser.parse(source.read_bytes())
        assert not tree.root_node.has_error, f'C# syntax error in {source}'
    print(f'PASS: C# syntax parsing for {len(shared)} shared source files.')
print('UNRUN: Unity import, API compilation, Edit/Play checks, Windows builds, phone multitouch, external playtest.')
