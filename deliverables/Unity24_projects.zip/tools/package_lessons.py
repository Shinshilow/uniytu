#!/usr/bin/env python3
"""Materialize 24 independent Unity projects and ZIPs; does not build executables."""
from pathlib import Path
import hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1]
COURSE=ROOT/'Unity24'
GUID=hashlib.md5(b'unity24/Lesson.cs').hexdigest()
SCENE='''%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!1 &1000
GameObject:
  m_ObjectHideFlags: 0
  m_PrefabParentObject: {fileID: 0}
  m_PrefabInternal: {fileID: 0}
  serializedVersion: 5
  m_Component:
  - component: {fileID: 1001}
  - component: {fileID: 1002}
  m_Layer: 0
  m_Name: Hour __HOUR__
  m_TagString: Untagged
  m_IsActive: 1
--- !u!4 &1001
Transform:
  m_ObjectHideFlags: 0
  m_PrefabParentObject: {fileID: 0}
  m_PrefabInternal: {fileID: 0}
  m_GameObject: {fileID: 1000}
  m_LocalRotation: {x: 0, y: 0, z: 0, w: 1}
  m_LocalPosition: {x: 0, y: 0, z: 0}
  m_LocalScale: {x: 1, y: 1, z: 1}
  m_Children: []
  m_Father: {fileID: 0}
  m_RootOrder: 0
--- !u!114 &1002
MonoBehaviour:
  m_ObjectHideFlags: 0
  m_PrefabParentObject: {fileID: 0}
  m_PrefabInternal: {fileID: 0}
  m_GameObject: {fileID: 1000}
  m_Enabled: 1
  m_EditorHideFlags: 0
  m_Script: {fileID: 11500000, guid: __GUID__, type: 3}
  m_Name:
  m_EditorClassIdentifier:
  hour: __HOUR__
  generated: 0
'''
CONTROLS={1:'Нажмите Play; куб доступен в Hierarchy и Inspector.',2:'Проверьте Cube: (0,2,-5), дочернюю Sphere: local (0,1,0).',3:'Четыре сферы и четыре Legacy Shader; процедурные текстуры вместо файлов книги.',4:'Terrain с пляжем, равниной и горным хребтом; собственные текстуры.',5:'Четыре камеры выводят четыре четверти экрана; четыре Point Light.',6:'WASD / стрелки; две финишные зоны, опасности, checkpoint; R — заново.',7:'Play; в Console три независимых скрипта: сумма 62250, 1–100 с заменами, 20 чисел Фибоначчи.',8:'Стрелки — X/Z; мышь — вращение куба и камеры; M — масштаб.',9:'Стрелки; сообщения входа/выхода/нахождения в Console.',10:'WASD / стрелки; вытолкните 5 шаров с платформы; таймер, R — заново.',11:'B — экземпляр Lamp в сохранённой позиции; Space — в Spawn Point.',12:'A/D — движение; Space — прыжок; собственный персонаж вместо CharacterRobotBoy.',13:'A/D, Space; три Tilemap: Ground, Background, Decoration; перспективная камера.',14:'Кнопка Start Game; отдельные Menu и Game; плавное появление и синтезированный звук.',15:'WASD — полёт; Space — стрельба; метеоры, фон, счёт; R — заново.',16:'Четыре собственные системы частиц; выделите объекты для изменения модулей.',17:'AnimationClip: дуга, мерцание, масштаб, цвет. Откройте окно Animation.',18:'W — ходьба; Shift+W — бег; C — присесть; Space — прыжок. Откройте Animator.',19:'Выберите Timeline Director; откройте Timeline: патруль, движение камеры, активация света.',20:'A/D — уклонение; зелёные бонусы добавляют 5 секунд; таймер и R.',21:'1/2/3 — звуки; Space — Play/Stop; L — повтор. Синтезированные звуки вместо OGG книги.',22:'Мультитач на телефоне; на ПК 1/2/3 — куб, перетаскивание мышью. ПК не проверяет мультитач.',23:'Course → Build Windows x64; после сборки запустите EXE из Builds/Hour23 вместе с папкой данных.',24:'Откройте Разбор_разработки.md; дополните фактическими наблюдениями после проверки игры.'}
LIMITS={3:'Нет оригинальных Brick_Texture.png и Brick_Normal.png.',4:'Нет Terrain Assets; деревья — собственные объекты, а не tree/detail layers из пакета.',6:'Самостоятельная реализация механик, без Standard Assets и оригинальных файлов примеров.',11:'Lamp построена из собственных примитивов.',12:'Нет оригинального CharacterRobotBoy и его анимаций.',13:'Собственные тайлы; оригинальная палитра книги не приложена.',14:'Нет Hour14Package.unitypackage, clouds.jpg и LevelManager; созданы замены.',15:'Нужен реальный внешний плейтест; отзывы не выдуманы.',16:'FireComplex и Smoke из Standard Assets отсутствуют; использованы собственные эффекты.',18:'Нет Ethan / ThirdPersonController: собственный Animator на капсуле не заменяет изучение оригинального рига.',21:'Нет looper.ogg, quick_laser.ogg, xxplosion.ogg; заменены синтезом.',22:'Нужен телефон и Unity Remote; в этой среде не проверено.',23:'EXE не собран: нужен активированный Unity Editor и Windows Build Support.',24:'Разбор — технический черновик по исходникам, а не выдуманный отчёт о выполненных тестах.'}

def main():
    out=ROOT/'deliverables';out.mkdir(exist_ok=True)
    items=json.loads((COURSE/'manifest.json').read_text())
    for item in items:
        h=item['hour'];d=COURSE/f'Hour{h:02d}';assets=d/'Assets';settings=d/'ProjectSettings'
        (assets/'Resources').mkdir(parents=True,exist_ok=True);(assets/'Scenes').mkdir(exist_ok=True);settings.mkdir(exist_ok=True)
        for group,folder in [('Runtime','Scripts'),('Editor','Editor')]:
            target=assets/folder;target.mkdir(exist_ok=True)
            for src in sorted((COURSE/'SharedSource'/group).glob('*.cs')):
                shutil.copy2(src,target/src.name)
                guid=hashlib.md5(('unity24/'+src.name).encode()).hexdigest()
                (target/(src.name+'.meta')).write_text(f'fileFormatVersion: 2\nguid: {guid}\nMonoImporter:\n  externalObjects: {{}}\n  serializedVersion: 2\n  defaultReferences: []\n  executionOrder: 0\n  icon: {{instanceID: 0}}\n  userData:\n  assetBundleName:\n  assetBundleVariant:\n')
        (assets/'Resources/hour.txt').write_text(str(h)+'\n')
        (assets/'Scenes/Lesson.unity').write_text(SCENE.replace('__GUID__',GUID).replace('__HOUR__',str(h)))
        # Exact editor release confirmed by the user's About Unity screenshot.
        (settings/'ProjectVersion.txt').write_text('m_EditorVersion: 2018.1.0f1\n')
        axes=[]
        for name,negative,positive,altneg,altpos,typ,axis in [('Horizontal','left','right','a','d',0,0),('Vertical','down','up','s','w',0,0),('Mouse X','','','','',1,0),('Mouse Y','','','','',1,1),('Submit','','return','','space',0,0),('Cancel','','escape','','',0,0),('Jump','','space','','',0,0)]:
            axes.append(f'''  - serializedVersion: 3
    m_Name: {name}
    descriptiveName:
    descriptiveNegativeName:
    negativeButton: {negative}
    positiveButton: {positive}
    altNegativeButton: {altneg}
    altPositiveButton: {altpos}
    gravity: 3
    dead: 0.001
    sensitivity: {1 if typ else 3}
    snap: 0
    invert: 0
    type: {typ}
    axis: {axis}
    joyNum: 0
''')
        (settings/'InputManager.asset').write_text('%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n--- !u!13 &1\nInputManager:\n  m_ObjectHideFlags: 0\n  serializedVersion: 2\n  m_Axes:\n'+''.join(axes))
        limit=LIMITS.get(h,'Специальных внешних материалов не требуется.')
        (d/'ОТКРЫТЬ.md').write_text(f'''# Час {h:02d} — {item['title']}

**Статус: исходный проект; импорт, компиляция, Play и сборка в Unity не проверены. EXE отсутствует.**

Упражнение: PDF, страница {item['pdf_page']} (печатная {item['book_page']}). Это самостоятельная реализация итогового упражнения; она не является копией всех промежуточных практикумов главы.

1. Распакуйте ZIP в отдельную папку. В Unity Hub выберите Add и эту папку (в ней Assets и ProjectSettings).
2. Целевая ветка API — Unity 2018.1. В ProjectVersion указан **2018.1.0f1**, подтверждённый вашим скриншотом. Полная компиляция в этом редакторе здесь не выполнялась.
3. Дождитесь импорта. CourseSetup автоматически создаёт сцену, ассеты и список Scenes in Build. Если импорт завершился без ошибок, но сцена не подготовилась, выберите Course → Prepare lesson scenes.
4. Нажмите Play. {CONTROLS[h]}
5. Для Windows-сборки установите Windows Build Support той же версии; выберите Course → Build Windows x64. Выход: соседняя с проектом папка Builds/Hour{h:02d}.

Для передачи игры архивируйте **всю папку сборки**, а не только EXE: Unity также нужны *_Data и сопутствующие DLL.

## Ограничения

{limit}

Сверьте результат с «Задание_из_книги.txt». В нём текст из предоставленного PDF; подписи рисунков могут извлекаться некорректно. Реальные отзывы и результаты запусков следует записать самостоятельно. Эти исходники пока нельзя считать готовой проверенной работой для сдачи.
''')
        (d/'.gitignore').write_text('Library/\nTemp/\nObj/\nLogs/\nBuilds/\nUserSettings/\n*.csproj\n*.sln\n')
    # Docs written separately are included on subsequent invocations too.
    for item in items:
        d=COURSE/f"Hour{item['hour']:02d}"
        with zipfile.ZipFile(out/(d.name+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
            for path in sorted(d.rglob('*')):
                if path.is_file():z.write(path,Path(d.name)/path.relative_to(d))
    with zipfile.ZipFile(out/'Unity24_исходные_проекты.zip','w',zipfile.ZIP_DEFLATED) as z:
        for path in sorted(COURSE.rglob('*')):
            if path.is_file():z.write(path,Path('Unity24')/path.relative_to(COURSE))
        for path in sorted((ROOT/'tools').glob('*')):
            if path.is_file():z.write(path,Path('tools')/path.name)
    print(f'Packaged {len(items)} project archives; no Unity builds performed.')
if __name__=='__main__':main()
