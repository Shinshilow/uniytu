# Час 18 — изучение Mecanim

Откройте Window → Animator, выберите Mecanim Actor. Созданы параметры Speed, Crouch, Jump; состояния Grounded, Airborne, Crouching; три дерева смешивания и переходы. Внутри деревьев используются собственные простые клипы движения капсулы.

Это не анимированный человек и не ретаргетинг Humanoid. Книга предлагает дополнительно изучить ThirdPersonController.prefab с персонажем Ethan. Его нет в приложенном PDF: нужен отдельный пакет Standard Assets, совместимый с Unity 2018.1.

Проверьте переходы W, Shift+W, C, Space; затем сравните с оригинальным контроллером. Запишите фактические наблюдения. Документация: https://docs.unity3d.com/2018.1/Documentation/Manual/AnimationSection.html
