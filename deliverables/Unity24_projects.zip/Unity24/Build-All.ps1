param([Parameter(Mandatory=$true)][string]$UnityPath)
$ErrorActionPreference = 'Stop'
if (!(Test-Path -LiteralPath $UnityPath -PathType Leaf)) { throw 'Unity Editor executable not found.' }
foreach ($hour in 1..24) {
    $name = 'Hour{0:D2}' -f $hour
    & (Join-Path $PSScriptRoot "$name/Build-Windows.ps1") -UnityPath $UnityPath
    if (!$?) { throw "Build stopped at $name" }
}
Write-Host 'All 24 Windows builds completed. Distribute each entire Builds/HourNN folder.'
