using UnityEngine;
public class InputScript : MonoBehaviour
{
    void Update()
    {
        // A finger keeps its cube until release even when other fingers are lifted.
        // fingerId is an arbitrary identifier, not reliably 0, 1, 2.
        TouchRouting.UpdateRouting();
        foreach(var touch in Input.touches)
        {
            int index=TouchRouting.CubeFor(touch.fingerId);
            if(name=="Cube"+(index+1)&&touch.phase==TouchPhase.Moved)
                transform.Translate(touch.deltaPosition.x*.05f,touch.deltaPosition.y*.05f,0);
        }
    }
}
public static class TouchRouting
{
    static readonly System.Collections.Generic.Dictionary<int,int> fingers=new System.Collections.Generic.Dictionary<int,int>();
    static int frame=-1;
    public static void UpdateRouting()
    {
        if(frame==Time.frameCount)return;frame=Time.frameCount;
        if(Input.touchCount==0){fingers.Clear();return;}
        var remove=new System.Collections.Generic.List<int>();
        foreach(var pair in fingers)
        {
            bool found=false;foreach(var t in Input.touches)if(t.fingerId==pair.Key&&t.phase!=TouchPhase.Ended&&t.phase!=TouchPhase.Canceled)found=true;
            if(!found)remove.Add(pair.Key);
        }
        foreach(var id in remove)fingers.Remove(id);
        foreach(var t in Input.touches)
        {
            if(t.phase==TouchPhase.Ended||t.phase==TouchPhase.Canceled||fingers.ContainsKey(t.fingerId))continue;
            for(int i=0;i<3;i++)if(!fingers.ContainsValue(i)){fingers.Add(t.fingerId,i);break;}
        }
    }
    public static int CubeFor(int id){int result;return fingers.TryGetValue(id,out result)?result:-1;}
}
