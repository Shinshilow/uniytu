using UnityEngine;
[RequireComponent(typeof(CanvasGroup))]
public class FadeIn : MonoBehaviour
{
    float elapsed;
    void OnEnable(){elapsed=0;GetComponent<CanvasGroup>().alpha=0;}
    void Update(){elapsed+=Time.deltaTime;var group=GetComponent<CanvasGroup>();group.alpha=Mathf.Clamp01(elapsed/1.5f);group.interactable=elapsed>=1.5f;}
}
