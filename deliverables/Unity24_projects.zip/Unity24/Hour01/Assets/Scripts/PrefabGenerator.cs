using UnityEngine;
public class PrefabGenerator : MonoBehaviour
{
    public GameObject prefab;
    void Update()
    {
        if(prefab==null)return;
        if(Input.GetKeyDown(KeyCode.B))Instantiate(prefab);
        if(Input.GetKeyDown(KeyCode.Space))Instantiate(prefab,transform.position,transform.rotation);
    }
}
