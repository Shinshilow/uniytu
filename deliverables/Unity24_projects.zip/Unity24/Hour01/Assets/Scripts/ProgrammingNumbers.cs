using UnityEngine;
public class ProgrammingNumbers : MonoBehaviour
{
    void Start(){for(int n=1;n<=100;n++)Debug.Log(n%3==0||n%5==0?"Программирование — это прекрасно!":n.ToString());}
}
