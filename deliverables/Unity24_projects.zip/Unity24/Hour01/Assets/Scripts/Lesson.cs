using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.Tilemaps;

// API target: Unity 2018.1, built-in renderer. No external packages.
public class Lesson : MonoBehaviour
{
    public int hour = 1;
    public bool generated;
    public GameObject player;
    public GameObject lampPrefab;
    public Text status;
    public AudioSource sound;
    public AudioClip[] clips;
    public float elapsed;
    public int score;
    public bool finished;
    public bool won;
    public string message = "";
    public int lives = 3;
    public float timeLeft = 60;
    public float spawnClock;
    public float fireClock;
    public int selectedCube;
    public List<GameObject> balls = new List<GameObject>();
    public List<GameObject> touchCubes = new List<GameObject>();
    Vector3 lastMouse;
    static readonly Color teal = new Color(.15f,.8f,.85f);

    public static GameObject Shape(string name, PrimitiveType type, Vector3 pos, Vector3 scale, Color color)
    {
        var go = GameObject.CreatePrimitive(type);
        go.name = name; go.transform.position = pos; go.transform.localScale = scale;
        var mat = new Material(Shader.Find("Standard")); mat.color = color;
        go.GetComponent<Renderer>().sharedMaterial = mat;
        return go;
    }
    public static Camera CameraAt(Vector3 pos, Vector3 look, bool ortho, float size)
    {
        var go = new GameObject("Main Camera"); go.tag = "MainCamera";
        var camera = go.AddComponent<Camera>();
        go.AddComponent<AudioListener>();
        go.transform.position = pos; go.transform.LookAt(look);
        camera.orthographic = ortho; camera.orthographicSize = size;
        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.backgroundColor = new Color(.035f,.055f,.1f);
        camera.farClipPlane = 500;
        return camera;
    }
    public static Light LightAt(string name, LightType type, Vector3 pos, Color color)
    {
        var go = new GameObject(name); go.transform.position = pos;
        var light = go.AddComponent<Light>(); light.type = type;
        light.color = color; light.range = 15; light.intensity = 2;
        go.transform.rotation = Quaternion.Euler(45,-30,0);
        return light;
    }
    public static Rigidbody Body(GameObject go, bool gravity)
    {
        var rb = go.AddComponent<Rigidbody>(); rb.useGravity = gravity; return rb;
    }
    public void Generate()
    {
        if (generated) return;
        generated = true;
        RenderSettings.ambientLight = new Color(.25f,.28f,.35f);
        CameraAt(new Vector3(0,5,-14),Vector3.zero,false,6);
        LightAt("Directional Light",LightType.Directional,new Vector3(0,10,-10),Color.white);
        switch(hour)
        {
            case 1:
                player = Shape("Cube",PrimitiveType.Cube,Vector3.zero,Vector3.one,teal); break;
            case 2:
                player = Shape("Cube",PrimitiveType.Cube,new Vector3(0,2,-5),Vector3.one,teal);
                var sphere = Shape("Sphere (child)",PrimitiveType.Sphere,Vector3.zero,Vector3.one,Color.yellow);
                sphere.transform.SetParent(player.transform); sphere.transform.localPosition = new Vector3(0,1,0);
                Camera.main.transform.position = new Vector3(0,4,-13); Camera.main.transform.LookAt(player.transform); break;
            case 3: MaterialsDemo(); break;
            case 4: TerrainDemo(); break;
            case 5: CameraDemo(); break;
            case 6: Race(); break;
            case 7: Camera.main.gameObject.AddComponent<EvenSum>(); Camera.main.gameObject.AddComponent<ProgrammingNumbers>(); Camera.main.gameObject.AddComponent<Fibonacci>(); break;
            case 8:
                player = Shape("Cube",PrimitiveType.Cube,new Vector3(0,0,-5),Vector3.one,teal);
                player.AddComponent<CubeControlScript>(); break;
            case 9: Triggers(); break;
            case 10: Chaos(); break;
            case 11: Prefabs(); break;
            case 12: PlatformScene(false); break;
            case 13: PlatformScene(true); break;
            case 14: Menu(); break;
            case 15: Shooter(); break;
            case 16: Particles(); break;
            case 17: AnimationDemo(); break;
            case 18: AnimatorDemo(); break;
            case 19: TimelineDemo(); break;
            case 20: Runner(); break;
            case 21: AudioDemo(); break;
            case 22: TouchDemo(); break;
            case 23: Race(); break;
            case 24: Menu(); break;
        }
        Overlay();
    }
    void Start()
    {
        Generate();
        foreach(var button in FindObjectsOfType<Button>()) { if(button.name=="Start Game")button.onClick.AddListener(LoadGame);if(button.name=="Quit")button.onClick.AddListener(Quit); }
        if (hour == 21) { clips = new [] { Tone(220,.8f,0), Tone(900,.25f,1), Tone(65,.6f,2) }; sound.clip = clips[0]; }
        if (hour == 14 || hour == 24) { sound = gameObject.AddComponent<AudioSource>(); sound.loop = true; sound.clip = Tone(330,2,0); sound.volume = .12f; sound.Play(); }
    }
    void Overlay()
    {
        if (FindObjectOfType<EventSystem>() == null) new GameObject("EventSystem",typeof(EventSystem),typeof(StandaloneInputModule));
        var canvasObject = new GameObject("Lesson UI",typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));
        var canvas = canvasObject.GetComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasObject.GetComponent<CanvasScaler>(); scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize; scaler.referenceResolution = new Vector2(1000,700);
        var box = new GameObject("Instructions",typeof(RectTransform),typeof(Image)); box.transform.SetParent(canvasObject.transform,false);
        var r=box.GetComponent<RectTransform>(); r.anchorMin=new Vector2(0,1);r.anchorMax=new Vector2(1,1);r.pivot=new Vector2(.5f,1);r.sizeDelta=new Vector2(0,145);r.anchoredPosition=Vector2.zero;
        box.GetComponent<Image>().color = new Color(0,0,0,.8f);
        status = MakeText(box.transform,"Status","",18);
        var rt=status.rectTransform;rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.offsetMin=new Vector2(18,8);rt.offsetMax=new Vector2(-18,-8);
        status.alignment=TextAnchor.UpperLeft;
    }
    public static Text MakeText(Transform parent,string name,string value,int size)
    {
        var g=new GameObject(name,typeof(RectTransform),typeof(Text));g.transform.SetParent(parent,false);
        var t=g.GetComponent<Text>();t.font=Resources.GetBuiltinResource<Font>("Arial.ttf");t.text=value;t.fontSize=size;t.color=Color.white;t.alignment=TextAnchor.MiddleCenter;return t;
    }
    public void UIButton(Transform parent,string title,Vector2 pos,UnityEngine.Events.UnityAction action)
    {
        var g=new GameObject(title,typeof(RectTransform),typeof(Image),typeof(Button));g.transform.SetParent(parent,false);
        var r=g.GetComponent<RectTransform>();r.sizeDelta=new Vector2(260,48);r.anchoredPosition=pos;
        g.GetComponent<Image>().color=new Color(.1f,.35f,.5f);if(Application.isPlaying)g.GetComponent<Button>().onClick.AddListener(action);
        var t=MakeText(g.transform,"Label",title,22);t.rectTransform.anchorMin=Vector2.zero;t.rectTransform.anchorMax=Vector2.one;t.rectTransform.offsetMin=Vector2.zero;t.rectTransform.offsetMax=Vector2.zero;
    }
    void MaterialsDemo()
    {
        var tex = Brick(false);var norm=Brick(true);
        var shaders=new [] {"Legacy Shaders/Diffuse","Legacy Shaders/Specular","Legacy Shaders/Bumped Diffuse","Legacy Shaders/Bumped Specular"};
        var names=new [] {"DiffuseBrick","SpecularBrick","BumpedBrick","BumpedSpecularBrick"};
        var points=new [] {new Vector3(1,2,-5),new Vector3(-1,0,-5),new Vector3(1,0,-5),new Vector3(-1,2,-5)};
        for(int i=0;i<4;i++) {var go=Shape(names[i],PrimitiveType.Sphere,points[i],Vector3.one*2,Color.white);var mat=new Material(Shader.Find(shaders[i]));mat.name=names[i];mat.mainTexture=tex;if(i>=2)mat.SetTexture("_BumpMap",norm);go.GetComponent<Renderer>().sharedMaterial=mat;}
        Camera.main.transform.position=new Vector3(0,1,-13);Camera.main.transform.LookAt(new Vector3(0,1,-5));
        FindObjectOfType<Light>().transform.eulerAngles=new Vector3(30,-180,0);
    }
    public static Texture2D Brick(bool normal)
    {
        var t=new Texture2D(64,64);t.name=normal?"Brick_Normal_generated":"Brick_Texture_generated";t.anisoLevel=3;
        for(int y=0;y<64;y++)for(int x=0;x<64;x++){bool mortar=y%16<2||(x+(y/16%2)*16)%32<2;t.SetPixel(x,y,normal?new Color(.5f,.5f,mortar?.7f:1):mortar?Color.gray:new Color(.65f,.22f,.13f));}t.Apply();return t;
    }
    public void TerrainDemo()
    {
        var data = new TerrainData();data.name="Beach_Mountains_Plain";data.heightmapResolution=129;data.size=new Vector3(100,24,100);
        var heights=new float[129,129];
        for(int z=0;z<129;z++)for(int x=0;x<129;x++) {float nx=x/128f,nz=z/128f;float ridge=Mathf.Exp(-Mathf.Pow((nz-.8f)*12,2))*(.4f+.2f*Mathf.PerlinNoise(nx*8,nz*8));heights[z,x]=.04f+.08f*Mathf.SmoothStep(0,1,(nz-.15f)*5)+ridge;}
        data.SetHeights(0,0,heights);
        // SplatPrototype is the Unity 2018.1 terrain API.
        var splats=new SplatPrototype[3];Color[] colors={new Color(.8f,.68f,.42f),new Color(.25f,.45f,.18f),new Color(.35f,.34f,.31f)};
        for(int i=0;i<3;i++){var t=new Texture2D(8,8);t.name="GeneratedTerrainTexture"+i;for(int y=0;y<8;y++)for(int x=0;x<8;x++)t.SetPixel(x,y,colors[i]*(.9f+.1f*Mathf.PerlinNoise(x,y)));t.Apply();splats[i]=new SplatPrototype{texture=t,tileSize=new Vector2(8,8)};}
        data.splatPrototypes=splats;var alpha=new float[data.alphamapHeight,data.alphamapWidth,3];
        for(int z=0;z<data.alphamapHeight;z++)for(int x=0;x<data.alphamapWidth;x++){float nz=z/(float)(data.alphamapHeight-1);float sand=1-Mathf.SmoothStep(0,1,Mathf.InverseLerp(.16f,.35f,nz));float rock=Mathf.SmoothStep(0,1,Mathf.InverseLerp(.65f,.8f,nz));alpha[z,x,0]=sand;alpha[z,x,1]=1-sand-rock;alpha[z,x,2]=rock;}
        data.SetAlphamaps(0,0,alpha);var land=Terrain.CreateTerrainGameObject(data);land.name="Terrain";land.transform.position=new Vector3(-50,-3,-20);
        Shape("Sea (generated)",PrimitiveType.Cube,new Vector3(0,-1,-30),new Vector3(100,.2f,35),new Color(.1f,.4f,.65f));
        Camera.main.transform.position=new Vector3(65,45,-55);Camera.main.transform.LookAt(new Vector3(0,2,25));
        for(int i=0;i<12;i++){float x=-40+i*7;float z=15+i%3*4;var tree=Shape("Tree trunk",PrimitiveType.Cylinder,new Vector3(x,2,z),new Vector3(.4f,2,.4f),new Color(.35f,.2f,.1f));Shape("Tree crown",PrimitiveType.Sphere,tree.transform.position+Vector3.up*3,Vector3.one*3,Color.green);}
    }
    void CameraDemo()
    {
        var main=Camera.main; DestroyNow(main.gameObject);foreach(var light in FindObjectsOfType<Light>())DestroyNow(light.gameObject);
        Shape("Sphere",PrimitiveType.Sphere,Vector3.zero,Vector3.one,Color.white);
        Vector3[] ps={new Vector3(-4,0,0),new Vector3(4,0,0),new Vector3(0,0,-4),new Vector3(0,0,4)};Color[] cs={Color.red,Color.green,Color.blue,Color.yellow};
        for(int i=0;i<4;i++){LightAt("Point Light "+i,LightType.Point,ps[i],cs[i]);var cam=CameraAt(-ps[i]/2,Vector3.zero,false,5);cam.name="Camera "+i;cam.rect=new Rect((i%2)*.5f,(i/2)*.5f,.5f,.5f);if(i>0)DestroyNow(cam.GetComponent<AudioListener>());}
        RenderSettings.ambientLight=Color.black;
    }
    public static void DestroyNow(UnityEngine.Object obj){if(Application.isPlaying)Destroy(obj);else DestroyImmediate(obj);}
    void Ground(float width,float depth)
    {Shape("Ground",PrimitiveType.Cube,new Vector3(0,-.6f,0),new Vector3(width,1,depth),new Color(.14f,.24f,.3f));}
    void Race()
    {
        Ground(25,55);player=Shape("Racer",PrimitiveType.Capsule,new Vector3(0,.6f,-20),Vector3.one,teal);
        Body(player,false).constraints=RigidbodyConstraints.FreezeRotation|RigidbodyConstraints.FreezePositionY;
        var motor=player.AddComponent<LessonActor>();motor.mode="racer";motor.lesson=this;
        for(int i=0;i<8;i++){var hazard=Shape("Water hazard",PrimitiveType.Cube,new Vector3((i%2==0?-1:1)*5,-.05f,-14+i*4),new Vector3(8,.3f,1.5f),Color.blue);hazard.GetComponent<Collider>().isTrigger=true;var a=hazard.AddComponent<LessonActor>();a.mode="hazard";a.lesson=this;}
        for(int i=0;i<2;i++){var goal=Shape("Finish "+(i+1),PrimitiveType.Cube,new Vector3(i==0?-7:7,.6f,23),new Vector3(7,2,1),Color.green);goal.GetComponent<Collider>().isTrigger=true;var a=goal.AddComponent<LessonActor>();a.mode="finish";a.lesson=this;}
        var checkpoint=Shape("Checkpoint",PrimitiveType.Cube,new Vector3(0,.5f,5),new Vector3(25,1,.4f),Color.yellow);checkpoint.GetComponent<Collider>().isTrigger=true;var cp=checkpoint.AddComponent<LessonActor>();cp.mode="checkpoint";cp.lesson=this;
        Camera.main.transform.position=new Vector3(0,25,-30);Camera.main.transform.LookAt(new Vector3(0,0,0));
    }
    void Triggers()
    {
        player=Shape("Sphere",PrimitiveType.Sphere,new Vector3(0,0,-5),Vector3.one,teal);Body(player,false).constraints=RigidbodyConstraints.FreezeRotation|RigidbodyConstraints.FreezePositionY;player.AddComponent<MotionScript>();
        for(int i=0;i<2;i++){var t=Shape(i==0?"LTrigger":"RTrigger",PrimitiveType.Cube,new Vector3(i==0?-1.5f:1.5f,0,-5),new Vector3(.1f,2,2),i==0?Color.yellow:Color.magenta);t.GetComponent<Collider>().isTrigger=true;t.AddComponent<TriggerScript>();}
    }
    void Chaos()
    {
        Ground(20,20);player=Shape("Bumper",PrimitiveType.Cylinder,new Vector3(0,.5f,0),new Vector3(2,.5f,2),teal);var rb=Body(player,true);rb.constraints=RigidbodyConstraints.FreezeRotation;rb.mass=4;var a=player.AddComponent<LessonActor>();a.mode="bumper";a.lesson=this;
        for(int i=0;i<5;i++){var ball=Shape("Chaos Ball "+i,PrimitiveType.Sphere,new Vector3(Mathf.Cos(i*1.25f)*6,.5f,Mathf.Sin(i*1.25f)*6),Vector3.one*(.8f+i*.1f),Color.Lerp(Color.red,Color.yellow,i/5f));Body(ball,true).velocity=new Vector3(Mathf.Sin(i)*3,0,Mathf.Cos(i)*3);balls.Add(ball);}
        Camera.main.transform.position=new Vector3(0,22,-8);Camera.main.transform.LookAt(Vector3.zero);
    }
    void Prefabs()
    {
        foreach(var light in FindObjectsOfType<Light>())DestroyNow(light.gameObject);
        Shape("Backdrop",PrimitiveType.Cube,new Vector3(0,0,-4),new Vector3(12,8,.1f),Color.gray);
        var spawn=new GameObject("Spawn Point");spawn.transform.position=new Vector3(1,1,-5);
        var generator=spawn.AddComponent<PrefabGenerator>();generator.prefab=lampPrefab;
    }
    public static GameObject Lamp()
    {
        var root=new GameObject("Lamp");root.transform.position=new Vector3(-1,0,-5);
        var stem=Shape("Stem",PrimitiveType.Cylinder,new Vector3(-1,0,-5),new Vector3(.12f,.8f,.12f),Color.gray);stem.transform.SetParent(root.transform,true);
        var bulb=Shape("Bulb",PrimitiveType.Sphere,new Vector3(-1,1,-5),Vector3.one*.5f,Color.yellow);bulb.transform.SetParent(root.transform,true);
        var light=LightAt("Lamp Light",LightType.Point,new Vector3(-1,1,-5),Color.yellow);light.transform.SetParent(root.transform,true);light.range=7;return root;
    }
    public static Sprite SolidSprite(Color color)
    {var t=new Texture2D(16,16);t.name="GeneratedSprite";for(int y=0;y<16;y++)for(int x=0;x<16;x++)t.SetPixel(x,y,color);t.Apply();return Sprite.Create(t,new Rect(0,0,16,16),new Vector2(.5f,.5f),16);}
    public static GameObject SpriteObject(string name,Vector3 pos,Vector3 scale,Color color)
    {var g=new GameObject(name);g.transform.position=pos;g.transform.localScale=scale;g.AddComponent<SpriteRenderer>().sprite=SolidSprite(color);return g;}
    void PlatformScene(bool tilemap)
    {
        var cam=Camera.main;cam.transform.position=new Vector3(11,4,-10);cam.transform.rotation=Quaternion.identity;cam.orthographic=!tilemap;cam.orthographicSize=7;
        player=SpriteObject("Player (replacement for RobotBoy)",new Vector3(3,1.8f,0),new Vector3(.8f,1.6f,1),teal);player.AddComponent<BoxCollider2D>();player.AddComponent<Rigidbody2D>().freezeRotation=true;player.AddComponent<PlatformMotor>();
        if(!tilemap)
        {
            for(int i=0;i<2;i++){var p=SpriteObject("PlatformWhiteSprite_generated",new Vector3(i*7.5f,0,0),new Vector3(6,.5f,1),Color.white);p.transform.eulerAngles=new Vector3(0,0,i*30);p.AddComponent<BoxCollider2D>();}
        }
        else
        {
            var grid=new GameObject("Grid",typeof(Grid));
            for(int layer=0;layer<3;layer++)
            {
                var g=new GameObject(new[]{"Ground","Background","Decoration"}[layer],typeof(Tilemap),typeof(TilemapRenderer));g.transform.SetParent(grid.transform);g.transform.localPosition=new Vector3(0,0,layer==1?8:-layer*.05f);
                var map=g.GetComponent<Tilemap>();var tile=ScriptableObject.CreateInstance<Tile>();tile.name=g.name+" Tile";tile.sprite=SolidSprite(layer==0?new Color(.35f,.55f,.25f):layer==1?new Color(.24f,.32f,.46f):Color.green);
                if(layer==0){for(int x=-12;x<50;x++)for(int y=-3;y<=0;y++)map.SetTile(new Vector3Int(x,y,0),tile);for(int x=7;x<45;x+=7)map.SetTile(new Vector3Int(x,3,0),tile);g.AddComponent<TilemapCollider2D>();}
                if(layer==1)for(int x=-15;x<60;x++)for(int y=-3;y<2+(x/5%3);y++)map.SetTile(new Vector3Int(x,y,0),tile);
                if(layer==2)for(int x=-8;x<45;x+=6)map.SetTile(new Vector3Int(x,1,0),tile);
            }
            var follow=cam.gameObject.AddComponent<CameraFollow>();follow.target=player.transform;follow.offset=new Vector3(4,3,-12);
        }
    }
    void Menu()
    {
        var c=new GameObject("Menu Canvas",typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster),typeof(CanvasGroup),typeof(FadeIn));c.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;
        var panel=new GameObject("Clouds panel (generated)",typeof(RectTransform),typeof(Image));panel.transform.SetParent(c.transform,false);var r=panel.GetComponent<RectTransform>();r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=Vector2.zero;r.offsetMax=Vector2.zero;panel.GetComponent<Image>().color=new Color(.1f,.2f,.38f);
        var title=MakeText(panel.transform,"Title",hour==24?"Разбор разработки":"UNITY — 24 ЧАСА",34);title.rectTransform.sizeDelta=new Vector2(800,100);title.rectTransform.anchoredPosition=new Vector2(0,100);
        var subtitle=MakeText(panel.transform,"Subtitle",hour==24?"Письменный разбор — в папке проекта":"Час 14 · Меню и переход между сценами",18);subtitle.rectTransform.sizeDelta=new Vector2(800,60);subtitle.rectTransform.anchoredPosition=new Vector2(0,35);
        UIButton(panel.transform,"Start Game",new Vector2(0,-45),LoadGame);
        UIButton(panel.transform,"Quit",new Vector2(0,-110),Quit);
    }
    public void LoadGame(){SceneManager.LoadScene("Game");}
    public void Quit(){Application.Quit();}
    void Shooter()
    {
        var cam=Camera.main;cam.transform.position=new Vector3(0,0,-10);cam.transform.rotation=Quaternion.identity;cam.orthographic=true;cam.orthographicSize=6;
        player=SpriteObject("Captain Blaster",new Vector3(0,-4,0),new Vector3(.7f,1,1),teal);player.AddComponent<BoxCollider2D>().isTrigger=true;player.AddComponent<Rigidbody2D>().isKinematic=true;
        var a=player.AddComponent<LessonActor>();a.lesson=this;a.mode="ship";
        for(int i=0;i<70;i++){var star=SpriteObject("Scrolling star",new Vector3(UnityEngine.Random.Range(-9f,9f),UnityEngine.Random.Range(-7f,8f),1),Vector3.one*UnityEngine.Random.Range(.03f,.09f),Color.white);var st=star.AddComponent<LessonActor>();st.mode="star";st.lesson=this;}
    }
    void Particles()
    {
        Ground(22,12);string[] names={"FireComplex_generated","Smoke_generated","Explosion_generated","Fireworks_generated"};Color[] colors={new Color(1,.3f,.03f),Color.gray,Color.yellow,Color.cyan};
        for(int i=0;i<4;i++)
        {
            var go=new GameObject(names[i],typeof(ParticleSystem));go.transform.position=new Vector3(-6+i*4,0,0);go.transform.eulerAngles=new Vector3(-90,0,0);var p=go.GetComponent<ParticleSystem>();var main=p.main;main.startColor=colors[i];main.startLifetime=i==1?4:1.5f;main.startSpeed=i==1?1:3;main.startSize=i==1?1:.25f;main.maxParticles=500;
            var emission=p.emission;emission.rateOverTime=i==1?15:40;var shape=p.shape;shape.shapeType=ParticleSystemShapeType.Cone;shape.angle=i>=2?65:15;
            var fade=p.colorOverLifetime;fade.enabled=true;var gradient=new Gradient();gradient.SetKeys(new[]{new GradientColorKey(colors[i],0),new GradientColorKey(colors[i]*.5f,1)},new[]{new GradientAlphaKey(1,0),new GradientAlphaKey(0,1)});fade.color=gradient;
            go.GetComponent<ParticleSystemRenderer>().sharedMaterial=new Material(Shader.Find("Particles/Standard Unlit"));
        }
    }
    void AnimationDemo(){player=Shape("Animated Cube",PrimitiveType.Cube,Vector3.zero,Vector3.one,teal);}
    void AnimatorDemo(){player=Shape("Mecanim Actor (Ethan substitute)",PrimitiveType.Capsule,Vector3.zero,Vector3.one,teal);player.AddComponent<Animator>();var a=player.AddComponent<LessonActor>();a.lesson=this;a.mode="animator";Ground(12,12);}
    void TimelineDemo(){player=Shape("Guard",PrimitiveType.Capsule,new Vector3(-3,0,0),Vector3.one,teal);Ground(15,15);LightAt("Timeline spotlight",LightType.Point,new Vector3(0,3,-2),Color.magenta);}
    void Runner()
    {
        Ground(12,70);player=Shape("Runner",PrimitiveType.Capsule,new Vector3(0,.5f,-10),Vector3.one,teal);var rb=Body(player,false);rb.constraints=RigidbodyConstraints.FreezeRotation|RigidbodyConstraints.FreezePositionY;var a=player.AddComponent<LessonActor>();a.mode="runner";a.lesson=this;
        Camera.main.transform.position=new Vector3(0,7,-20);Camera.main.transform.LookAt(new Vector3(0,0,8));
    }
    void AudioDemo()
    {
        player=Shape("Audio Cube",PrimitiveType.Cube,new Vector3(0,0,-10),Vector3.one,teal);sound=player.AddComponent<AudioSource>();sound.playOnAwake=false;
        Camera.main.transform.position=new Vector3(0,2,-16);Camera.main.transform.LookAt(player.transform);
    }
    public static AudioClip Tone(float frequency,float seconds,int kind)
    {
        int rate=22050;var clip=AudioClip.Create("Synthesized substitute "+kind,(int)(rate*seconds),1,rate,false);var data=new float[clip.samples];var random=new System.Random(42);
        for(int i=0;i<data.Length;i++){float t=i/(float)rate;float envelope=kind==0?.3f:.6f*(1-t/seconds);data[i]=envelope*(kind==2?(float)(random.NextDouble()*2-1):Mathf.Sin(2*Mathf.PI*frequency*t*(kind==1?1-t/seconds*.7f:1)));}clip.SetData(data,0);return clip;
    }
    void TouchDemo()
    {
        for(int i=0;i<3;i++){var cube=Shape("Cube"+(i+1),PrimitiveType.Cube,new Vector3(-3+i*3,1,-5),Vector3.one,Color.Lerp(teal,Color.magenta,i/2f));cube.AddComponent<InputScript>();touchCubes.Add(cube);}
        Camera.main.transform.position=new Vector3(0,3,-15);Camera.main.transform.LookAt(new Vector3(0,1,-5));
    }
    public void End(bool success,string text){if(finished)return;finished=true;won=success;message=text;}
    public void Restart(){SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);}
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape))Application.Quit();
        if(Input.GetKeyDown(KeyCode.R))Restart();
        if(!finished)elapsed+=Time.deltaTime;
        if(hour==10&&!finished)
        {
            int active=0;foreach(var ball in balls)if(ball!=null){if(ball.transform.position.y < -4){Destroy(ball);score++;}else active++;}if(active==0)End(true,"Все шары вытолкнуты с арены!");if(player.transform.position.y < -4)End(false,"Бампер упал");
        }
        if((hour==15||hour==20)&&!finished)
        {
            spawnClock-=Time.deltaTime;if(spawnClock<=0){spawnClock=hour==15?Mathf.Max(.35f,1-elapsed*.005f):.8f;SpawnObstacle();}
            if(hour==15){var p=player.transform.position;p.x=Mathf.Clamp(p.x+Input.GetAxisRaw("Horizontal")*7*Time.deltaTime,-8,8);p.y=Mathf.Clamp(p.y+Input.GetAxisRaw("Vertical")*7*Time.deltaTime,-5,5);player.transform.position=p;fireClock-=Time.deltaTime;if(Input.GetKey(KeyCode.Space)&&fireClock<=0){fireClock=.17f;var shot=SpriteObject("Laser",p+Vector3.up*.7f,new Vector3(.12f,.5f,1),Color.yellow);shot.AddComponent<BoxCollider2D>().isTrigger=true;shot.AddComponent<Rigidbody2D>().isKinematic=true;var a=shot.AddComponent<LessonActor>();a.lesson=this;a.mode="laser";}}
            else{timeLeft-=Time.deltaTime;if(timeLeft<=0)End(false,"Время вышло. Дистанция: "+Mathf.FloorToInt(elapsed*7));}
        }
        if(hour==21&&sound!=null)
        {
            if(Input.GetKeyDown(KeyCode.Space)){if(sound.isPlaying)sound.Stop();else sound.Play();}if(Input.GetKeyDown(KeyCode.L))sound.loop=!sound.loop;
            for(int i=0;i<3;i++)if(Input.GetKeyDown((KeyCode)((int)KeyCode.Alpha1+i))){sound.Stop();sound.clip=clips[i];sound.Play();}
        }
        if(hour==22) DesktopTouchFallback();
        if(status!=null)status.text="ЧАС "+hour.ToString("00")+"  |  "+Title()+"\n"+Controls()+"\n"+(finished?message+" · R — заново":"Время: "+elapsed.ToString("F1")+"   Очки: "+score+(hour==20?"   Осталось: "+timeLeft.ToString("F1"):""))+"\n"+(hour==9?TriggerScript.lastEvent:hour==21?"Звук: "+(sound.isPlaying?"играет":"остановлен")+" · Повтор: "+sound.loop:message);
    }
    void DesktopTouchFallback()
    {
        for(int i=0;i<3;i++)if(Input.GetKeyDown((KeyCode)((int)KeyCode.Alpha1+i)))selectedCube=i;
        if(Input.GetMouseButtonDown(0))lastMouse=Input.mousePosition;
        if(Input.GetMouseButton(0)&&Input.touchCount==0){var delta=Input.mousePosition-lastMouse;touchCubes[selectedCube].transform.Translate(delta.x*.02f,delta.y*.02f,0);lastMouse=Input.mousePosition;}
    }
    void SpawnObstacle()
    {
        if(hour==15){var rock=SpriteObject("Meteor",new Vector3(UnityEngine.Random.Range(-8f,8f),7,0),Vector3.one*UnityEngine.Random.Range(.5f,1.3f),new Color(.7f,.35f,.2f));rock.AddComponent<CircleCollider2D>().isTrigger=true;rock.AddComponent<Rigidbody2D>().isKinematic=true;var a=rock.AddComponent<LessonActor>();a.lesson=this;a.mode="meteor";}
        else{bool bonus=UnityEngine.Random.value<.3f;var g=Shape(bonus?"Time Bonus":"Obstacle",bonus?PrimitiveType.Sphere:PrimitiveType.Cube,new Vector3(UnityEngine.Random.Range(-4f,4f),.5f,30),Vector3.one,bonus?Color.green:Color.red);g.GetComponent<Collider>().isTrigger=true;var a=g.AddComponent<LessonActor>();a.lesson=this;a.mode=bonus?"bonus":"obstacle";}
    }
    string Title(){string[] t={"Введение","Объекты и иерархия","Материалы","Ландшафт","Свет и камеры","Гонщик","Основы C#","Управление","Триггеры","Шар хаоса","Префабы","2D-физика","Тайлмапы","Меню","Капитан Бластер","Частицы","Анимация","Mecanim","Timeline","Бег с препятствиями","Звук","Мультитач","Сборка","Разбор разработки"};return t[Mathf.Clamp(hour-1,0,23)];}
    string Controls()
    {
        switch(hour){case 6:case 23:return "WASD / стрелки — движение · две финишные зоны · R — заново";case 7:return "Три результата — в Console (сумма: 62250); расчёты запускаются при Play";case 8:return "Стрелки — X/Z · мышь — поворот · M — удвоение масштаба · R — сброс";case 9:return "Стрелки — движение · вход / нахождение / выход — в Console";case 10:return "Стрелки / WASD — толкайте шары за край · R — заново";case 11:return "B — Lamp в исходной позиции · Пробел — Lamp в Spawn Point";case 12:case 13:return "A/D / стрелки — движение · Пробел — прыжок · R — сброс";case 15:return "WASD / стрелки — полёт · Пробел — огонь · R — заново";case 18:return "W — ходьба · Shift+W — бег · C — присесть · Пробел — прыжок";case 19:return "Timeline запускается автоматически · R — повторить";case 20:return "A/D / стрелки — уклонение · зелёный бонус +5 секунд · R — заново";case 21:return "1/2/3 — выбрать звук · Пробел — Play/Stop · L — Loop";case 22:return "Телефон: три пальца · ПК: 1/2/3 — куб, тяните мышью · R — сброс";default:return "Play — демонстрация · R — перезапуск · исходные объекты доступны в Hierarchy";}
    }
}
