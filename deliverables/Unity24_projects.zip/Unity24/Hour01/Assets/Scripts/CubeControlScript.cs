using UnityEngine;
public class CubeControlScript : MonoBehaviour
{
    Vector3 original;bool large;
    void Start(){original=transform.localScale;}
    void Update()
    {
        transform.Translate(Input.GetAxisRaw("Horizontal")*4*Time.deltaTime,0,Input.GetAxisRaw("Vertical")*4*Time.deltaTime,Space.World);
        transform.Rotate(0,Input.GetAxis("Mouse X")*2,0,Space.World);
        if(Camera.main!=null)Camera.main.transform.Rotate(-Input.GetAxis("Mouse Y")*2,0,0,Space.Self);
        if(Input.GetKeyDown(KeyCode.M)){large=!large;transform.localScale=original*(large?2:1);}
    }
}
