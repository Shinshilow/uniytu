using UnityEngine;
[RequireComponent(typeof(Rigidbody))]
public class MotionScript : MonoBehaviour
{
    void FixedUpdate(){var body=GetComponent<Rigidbody>();body.MovePosition(body.position+new Vector3(Input.GetAxisRaw("Horizontal"),0,Input.GetAxisRaw("Vertical"))*3*Time.fixedDeltaTime);}
}
