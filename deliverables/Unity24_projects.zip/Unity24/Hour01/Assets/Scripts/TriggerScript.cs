using UnityEngine;
public class TriggerScript : MonoBehaviour
{
    public static string lastEvent="";
    float nextLog;
    void Report(string type){lastEvent=name+": "+type;Debug.Log(lastEvent);}
    void OnTriggerEnter(Collider other){if(other.GetComponent<MotionScript>()!=null)Report("вход");}
    void OnTriggerStay(Collider other){if(other.GetComponent<MotionScript>()!=null&&Time.time>=nextLog){nextLog=Time.time+.5f;Report("нахождение внутри");}}
    void OnTriggerExit(Collider other){if(other.GetComponent<MotionScript>()!=null)Report("выход");}
}
