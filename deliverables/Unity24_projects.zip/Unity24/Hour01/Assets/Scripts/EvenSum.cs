using UnityEngine;
public class EvenSum : MonoBehaviour
{
    void Start(){int sum=0;for(int n=2;n<=499;n+=2)sum+=n;Debug.Log("Сумма чётных от 2 до 499 = "+sum);}
}
