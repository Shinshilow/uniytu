using UnityEngine;
public class CameraFollow : MonoBehaviour
{
    public Transform target;public Vector3 offset=new Vector3(4,3,-12);
    void LateUpdate(){if(target!=null)transform.position=Vector3.Lerp(transform.position,target.position+offset,Time.deltaTime*5);}
}
