using UnityEngine;
[RequireComponent(typeof(Rigidbody2D),typeof(BoxCollider2D))]
public class PlatformMotor : MonoBehaviour
{
    public float speed=5;
    bool jump;
    void Update(){if(Input.GetKeyDown(KeyCode.Space))jump=true;if(transform.position.y < -12)transform.position=new Vector3(3,3,0);}
    void FixedUpdate()
    {
        var rb=GetComponent<Rigidbody2D>();rb.velocity=new Vector2(Input.GetAxisRaw("Horizontal")*speed,rb.velocity.y);
        var box=GetComponent<BoxCollider2D>();var bounds=box.bounds;
        // Cast from just below the character, avoiding its own collider.
        var hit=Physics2D.BoxCast(new Vector2(bounds.center.x,bounds.min.y-.04f),new Vector2(bounds.size.x*.8f,.03f),0,Vector2.down,.1f);
        if(jump&&hit.collider!=null&&rb.velocity.y<=.1f)rb.velocity=new Vector2(rb.velocity.x,9);
        jump=false;
    }
}
