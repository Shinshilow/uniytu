using UnityEngine;
public class Fibonacci : MonoBehaviour
{
    void Start(){int a=0,b=1;for(int i=0;i<20;i++){Debug.Log("Фибоначчи["+i+"] = "+a);int next=a+b;a=b;b=next;}}
}
