using UnityEngine;
public class LessonActor : MonoBehaviour
{
    public string mode;
    public Lesson lesson;
    public Vector3 respawn = new Vector3(0,.6f,-20);
    bool consumed;
    void FixedUpdate()
    {
        if(lesson==null||lesson.finished)return;
        if(mode=="racer"||mode=="bumper"||mode=="runner")
        {
            var rb=GetComponent<Rigidbody>();float x=Input.GetAxisRaw("Horizontal"),z=mode=="runner"?0:Input.GetAxisRaw("Vertical");
            rb.MovePosition(rb.position+new Vector3(x,0,z)*Time.fixedDeltaTime*(mode=="bumper"?9:7));
        }
    }
    void Update()
    {
        if(lesson==null||lesson.finished)return;
        if(mode=="star"){transform.Translate(0,-Time.deltaTime*2,0);if(transform.position.y < -7)transform.position+=Vector3.up*15;}
        if(mode=="meteor"){transform.Translate(0,-Time.deltaTime*(3+lesson.elapsed*.02f),0,Space.World);transform.Rotate(0,0,Time.deltaTime*25);if(transform.position.y < -8)Destroy(gameObject);}
        if(mode=="laser"){transform.Translate(0,Time.deltaTime*15,0);if(transform.position.y > 9)Destroy(gameObject);}
        if(mode=="bonus"||mode=="obstacle"){transform.Translate(0,0,-Time.deltaTime*(8+lesson.elapsed*.06f));if(transform.position.z < -15)Destroy(gameObject);}
        if(mode=="animator")
        {
            var animator=GetComponent<Animator>();float speed=Input.GetKey(KeyCode.W)?(Input.GetKey(KeyCode.LeftShift)?1:.5f):0;
            animator.SetFloat("Speed",speed);animator.SetBool("Crouch",Input.GetKey(KeyCode.C));if(Input.GetKeyDown(KeyCode.Space))animator.SetTrigger("Jump");
        }
    }
    void OnTriggerEnter(Collider other)
    {
        if(lesson==null||lesson.finished||other.gameObject!=lesson.player||consumed)return;
        if(mode=="finish")lesson.End(true,"Финиш достигнут");
        if(mode=="hazard"){var actor=other.GetComponent<LessonActor>();other.GetComponent<Rigidbody>().position=actor.respawn;lesson.message="Опасность: возврат к контрольной точке";}
        if(mode=="checkpoint"){other.GetComponent<LessonActor>().respawn=new Vector3(0,.6f,7);lesson.message="Контрольная точка сохранена";}
        if(mode=="bonus"){consumed=true;lesson.timeLeft+=5;lesson.score++;Destroy(gameObject);}
        if(mode=="obstacle"){consumed=true;lesson.End(false,"Столкновение. Пройдено: "+Mathf.FloorToInt(lesson.elapsed*7));}
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if(lesson==null||lesson.finished||consumed)return;
        var actor=other.GetComponent<LessonActor>();if(actor==null)return;
        if(mode=="meteor"&&actor.mode=="laser") {consumed=true;lesson.score++;Destroy(other.gameObject);Destroy(gameObject);}
        if(mode=="ship"&&actor.mode=="meteor")lesson.End(false,"Корабль уничтожен. Очки: "+lesson.score);
    }
}
