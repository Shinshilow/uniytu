param([Parameter(Mandatory=$true)][string]$UnityPath)
$ErrorActionPreference = 'Stop'
if (!(Test-Path -LiteralPath $UnityPath -PathType Leaf)) { throw 'Unity Editor executable not found.' }
$project = $PSScriptRoot
$log = Join-Path $project 'build-windows.log'
if (Test-Path -LiteralPath $log) { Remove-Item -LiteralPath $log }
& $UnityPath -batchmode -nographics -quit -projectPath $project -executeMethod CourseSetup.BuildWindows -logFile $log
if ($LASTEXITCODE -ne 0) { throw "Unity failed with exit code $LASTEXITCODE. See $log" }
if (!(Test-Path -LiteralPath $log)) { throw 'Unity did not produce the expected build log.' }
if (!(Select-String -LiteralPath $log -Pattern 'COURSE_BUILD_SUCCEEDED' -Quiet)) { throw "Build success was not confirmed. See $log" }
$target = Join-Path (Split-Path -Parent $project) 'Builds/Hour23/Hour23.exe'
if (!(Test-Path -LiteralPath $target)) { throw "Build output missing: $target" }
Write-Host "Built $target. Keep its _Data folder and DLLs beside the EXE."
