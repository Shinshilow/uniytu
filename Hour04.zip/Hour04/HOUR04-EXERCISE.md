# Час 4: итоговое упражнение

Откройте Assets/Scenes/Exercise Beach Mountains Plain.unity. Это сохранённая сцена с настоящим TerrainData, а не генератор при Play.

Пляж SandAlbedo плавно переходит в GrassRockyAlbedo; равнина покрыта GrassHillAlbedo, склоны — GrassRockyAlbedo, вершины и крутые участки — CliffAlbedoSpecular. Все четыре текстуры, Conifer_Desktop и GrassFrond01AlbedoAlpha взяты из оригинального пакета книги; исходные GUID сохранены. Деревья и трава хранятся в native Terrain tree/detail layers.

Terrain размером 100×60×100, карта высот 513×513. В сцене поставлен оригинальный FPSController: WASD, мышь, Space; Esc освобождает курсор. Его стартовая точка чуть выше равнины. Старая Main Camera удалена.

Практикумы книги сохранены в исходных сценах Sculpting Terrain, Applying Heightmap, Texturing Terrain и Adding Trees and Grass; оригинальные TerrainData не изменялись.

Проверено чтение записанного бинарного TerrainData, прототипы, 37 деревьев, настоящие detail patches и нормализованные alpha weights всех mipmaps. Unity Editor в этой среде не запускался; импорт, визуальный вид, управление и EXE требуют проверки в Unity 2018.1.0f1.
