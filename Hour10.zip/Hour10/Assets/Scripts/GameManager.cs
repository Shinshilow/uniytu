using UnityEngine;
using UnityEngine.SceneManagement;
using UnityStandardAssets.Characters.FirstPerson;

// Student extension for Hour 10's final exercise: a timer and restart controls.
// The four matching goals, ball physics and arena are the publisher's game.
public class GameManager : MonoBehaviour
{
    // Keep these names and types: Main.unity already saves these four references.
    public GoalScript blue, green, red, orange;

    private bool isGameOver;
    private bool restarting;
    private float elapsedSeconds;
    private FirstPersonController playerController;

    void Awake()
    {
        isGameOver = false;
        restarting = false;
        elapsedSeconds = 0f;
        playerController = FindObjectOfType<FirstPersonController>();

        if (blue == null || green == null || red == null || orange == null)
            Debug.LogError("Assign all four GoalScript references on Game Manager.", this);
    }

    void Update()
    {
        if (restarting)
            return;

        if (Input.GetKeyDown(KeyCode.R))
        {
            RestartGame();
            return;
        }

        if (isGameOver)
            return;

        elapsedSeconds += Time.deltaTime;
        if (blue != null && green != null && red != null && orange != null &&
            blue.isSolved && green.isSolved && red.isSolved && orange.isSolved)
        {
            isGameOver = true;
            // MouseLook otherwise locks the pointer every frame, hiding the button.
            // Disable only player input; preserve the original ball simulation.
            if (playerController != null)
                playerController.enabled = false;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }

    void OnGUI()
    {
        GUI.Box(new Rect(10, 10, 240, 55),
            "Time: " + elapsedSeconds.ToString("F1") + " s\nR: restart");

        if (!isGameOver)
            return;

        Rect panel = new Rect(Screen.width / 2f - 150f,
            Screen.height / 2f - 75f, 300f, 150f);
        GUI.Box(panel, "Game Over - Good Job!");
        GUI.Label(new Rect(panel.x + 20f, panel.y + 35f, 260f, 30f),
            "All four goals solved in " + elapsedSeconds.ToString("F1") + " s");
        if (GUI.Button(new Rect(panel.x + 60f, panel.y + 90f, 180f, 35f),
            "Restart (R)"))
            RestartGame();
    }

    private void RestartGame()
    {
        if (restarting)
            return;

        Scene scene = SceneManager.GetActiveScene();
        if (scene.buildIndex < 0)
        {
            Debug.LogError("Add the current Main scene to File > Build Settings before restarting.", this);
            return;
        }

        restarting = true;
        SceneManager.LoadScene(scene.buildIndex);
    }
}
