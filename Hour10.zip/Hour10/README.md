# Hour 10 final exercise extension

This overlay replaces only the original `Assets/Scripts/GameManager.cs` in a **copy** of the publisher's Chaos Ball project. Preserve the original `.cs.meta` and all four saved GoalScript references (`blue`, `green`, `red`, `orange`). This is a student extension, not a publisher file.

The printed final exercise suggests improvements including a timer and a restart button. The timer starts at zero, stops when all four original matching-color goals are solved, and appears during play. Press **R** at any point to reload the active scene. The victory panel also provides a **Restart** button; on victory the original FirstPersonController is disabled and the cursor released so that the button can be clicked. Scene reload restores the original controller, balls, goals and timer. Add Main to Build Settings; the assembled project is expected to include this entry.

No defeat condition, goal replacement, or Time.timeScale changes are introduced. The original ball simulation continues after victory. A restart guard prevents repeated reloads from the same frame. The initial game-over state is false, avoiding the publisher's initial pre-Update Game Over panel.

Validation: inspected against original GoalScript and FirstPersonController/MouseLook APIs for Unity 2018.1.0f1. Unity import, compilation, Play mode and Windows build have not been run in this environment.
